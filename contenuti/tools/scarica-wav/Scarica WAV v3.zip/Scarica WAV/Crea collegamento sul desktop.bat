@echo off
setlocal
title Scarica WAV - collegamento sul desktop
cd /d "%~dp0"

if not exist "Scarica WAV TAUH.pyw" (
    echo Non trovo "Scarica WAV TAUH.pyw": tieni questo file nella stessa cartella.
    goto fine
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$qui = (Get-Location).Path;" ^
  "$desktop = [Environment]::GetFolderPath('Desktop');" ^
  "$shell = New-Object -ComObject WScript.Shell;" ^
  "$c = $shell.CreateShortcut((Join-Path $desktop 'Scarica WAV.lnk'));" ^
  "$c.TargetPath = (Join-Path $qui 'Scarica WAV TAUH.pyw');" ^
  "$c.WorkingDirectory = $qui;" ^
  "$c.IconLocation = (Join-Path $qui 'interfaccia\icona.ico') + ',0';" ^
  "$c.Description = 'Scarica WAV - TAUH';" ^
  "$c.Save()"

if errorlevel 1 (
    echo Non sono riuscito a creare il collegamento.
) else (
    echo Fatto: sul desktop c'e' "Scarica WAV" con il logo TAUH.
    echo Puoi anche aggiungerlo alla barra delle applicazioni: tasto destro, "Mostra altre opzioni", "Aggiungi alla barra delle applicazioni".
)

:fine
echo.
pause
