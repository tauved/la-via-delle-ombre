#!/bin/zsh
# Versione da Terminale, solo download: doppio clic, incolla i link (uno per
# riga) e premi Invio su una riga vuota per partire.
# Dal Terminale puoi anche passare i link o un file .txt:
#     "./Scarica WAV.command" LINK [LINK ...]      "./Scarica WAV.command" lista.txt

QUI="${0:A:h}"
SCRIPT="$QUI/scarica_wav.py"

python_va_bene() {
    [ -x "$1" ] && "$1" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1
}

trova_python() {
    local p
    if /usr/bin/xcode-select -p >/dev/null 2>&1 && python_va_bene /usr/bin/python3; then
        echo /usr/bin/python3; return 0
    fi
    for p in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
        python_va_bene "$p" && { echo "$p"; return 0; }
    done
    for p in /Library/Frameworks/Python.framework/Versions/*/bin/python3(NOn); do
        python_va_bene "$p" && { echo "$p"; return 0; }
    done
    p=$(command -v python3 2>/dev/null)
    [ -n "$p" ] && python_va_bene "$p" && { echo "$p"; return 0; }
    return 1
}

pausa() {
    echo
    read -k 1 -s "risposta?Premi un tasto per chiudere questa finestra. "
    echo
}

if [ ! -f "$SCRIPT" ]; then
    echo "Non trovo scarica_wav.py: tieni questo file nella stessa cartella."
    pausa; exit 1
fi

PY=$(trova_python)
if [ -z "$PY" ]; then
    echo "Python 3 non trovato. Lancia prima \"Installa requisiti.command\" (oppure, nel"
    echo "Terminale:  xcode-select --install) e poi riapri questo file."
    pausa; exit 1
fi

cd "$QUI" || exit 1
"$PY" "$SCRIPT" "$@"
pausa
