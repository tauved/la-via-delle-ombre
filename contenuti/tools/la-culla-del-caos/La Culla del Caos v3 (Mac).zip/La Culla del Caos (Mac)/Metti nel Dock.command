#!/bin/zsh
# Crea in ~/Applications l'app «La Culla del Caos» (con il logo TAUH) che apre il
# programma di questa cartella, e se vuoi la mette nel Dock. Se poi sposti la
# cartella, rilancia questo file.

QUI="${0:A:h}"
NOME="La Culla del Caos"
APP="$HOME/Applications/$NOME.app"
PNG="$QUI/interfaccia/icona.png"
ICNS_PRONTA="$QUI/interfaccia/icona.icns"

pausa() {
    echo
    read -k 1 -s "risposta?Premi un tasto per chiudere questa finestra. "
    echo
}

if [ ! -f "$QUI/$NOME.py" ]; then
    echo "Non trovo \"$NOME.py\": tieni questo file nella stessa cartella del programma."
    pausa; exit 1
fi

echo "Creo l'app \"$NOME\" in ~/Applications..."
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources" || { echo "Non riesco a scrivere in ~/Applications."; pausa; exit 1; }

# --- Info.plist --------------------------------------------------------------------
cat > "$APP/Contents/Info.plist" <<'FINE'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleName</key>
	<string>La Culla del Caos</string>
	<key>CFBundleDisplayName</key>
	<string>La Culla del Caos</string>
	<key>CFBundleIdentifier</key>
	<string>it.tauh.la-culla-del-caos</string>
	<key>CFBundleVersion</key>
	<string>3</string>
	<key>CFBundleShortVersionString</key>
	<string>3.0</string>
	<key>CFBundlePackageType</key>
	<string>APPL</string>
	<key>CFBundleExecutable</key>
	<string>La Culla del Caos</string>
	<key>CFBundleIconFile</key>
	<string>icona</string>
	<key>CFBundleInfoDictionaryVersion</key>
	<string>6.0</string>
	<key>LSMinimumSystemVersion</key>
	<string>10.13</string>
	<key>NSHighResolutionCapable</key>
	<true/>
	<key>NSHumanReadableCopyright</key>
	<string>TAUH</string>
</dict>
</plist>
FINE

# --- Eseguibile: trova Python 3 e lancia "La Culla del Caos.py" di questa cartella ----
LANCIATORE="$APP/Contents/MacOS/$NOME"
{
    echo '#!/bin/zsh'
    echo '# Creato da "Metti nel Dock.command": apre La Culla del Caos dalla cartella qui sotto.'
    echo "CARTELLA=${(qq)QUI}"
    cat <<'FINE'
PROGRAMMA="$CARTELLA/La Culla del Caos.py"
LOG="$HOME/Library/Application Support/ScaricaWAV/interfaccia.log"

avviso() {
    /usr/bin/osascript -e "display dialog \"$1\" with title \"La Culla del Caos\" buttons {\"OK\"} default button 1 with icon stop" >/dev/null 2>&1
}

python_va_bene() {
    [ -x "$1" ] && "$1" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1
}

trova_python() {
    local p
    if /usr/bin/xcode-select -p >/dev/null 2>&1 && python_va_bene /usr/bin/python3; then
        echo /usr/bin/python3; return 0
    fi
    for p in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
        python_va_bene "$p" && { echo "$p"; return 0; }
    done
    for p in /Library/Frameworks/Python.framework/Versions/*/bin/python3(NOn); do
        python_va_bene "$p" && { echo "$p"; return 0; }
    done
    p=$(command -v python3 2>/dev/null)
    [ -n "$p" ] && python_va_bene "$p" && { echo "$p"; return 0; }
    return 1
}

if [ ! -f "$PROGRAMMA" ]; then
    avviso "Non trovo più la cartella del programma: $CARTELLA. Se l'hai spostata, apri lì \"Metti nel Dock.command\" per rifare l'app."
    exit 1
fi
PY=$(trova_python)
if [ -z "$PY" ]; then
    avviso "Manca Python 3. Apri il Terminale e scrivi:  xcode-select --install  (oppure installa Python da python.org), poi riprova."
    exit 1
fi
mkdir -p "${LOG:h}" 2>/dev/null
"$PY" - "$PROGRAMMA" "$LOG" <<'PY'
import subprocess, sys
with open(sys.argv[2], "ab") as log:
    subprocess.Popen([sys.executable, sys.argv[1]], stdin=subprocess.DEVNULL,
                     stdout=log, stderr=log, start_new_session=True)
PY
FINE
} > "$LANCIATORE"
chmod +x "$LANCIATORE"

# --- Icona: dal PNG con sips + iconutil (sono in macOS); altrimenti quella pronta ----
ICNS="$APP/Contents/Resources/icona.icns"
fatta=0
if [ -f "$PNG" ] && command -v iconutil >/dev/null 2>&1 && command -v sips >/dev/null 2>&1; then
    TEMP=$(mktemp -d "${TMPDIR:-/tmp}/culla.XXXXXX")
    ICONSET="$TEMP/icona.iconset"
    mkdir -p "$ICONSET"
    for lato in 16 32 128 256 512; do
        sips -z $lato $lato "$PNG" --out "$ICONSET/icon_${lato}x${lato}.png" >/dev/null 2>&1
        doppio=$((lato * 2))
        sips -z $doppio $doppio "$PNG" --out "$ICONSET/icon_${lato}x${lato}@2x.png" >/dev/null 2>&1
    done
    if iconutil -c icns "$ICONSET" -o "$ICNS" >/dev/null 2>&1 && [ -s "$ICNS" ]; then
        fatta=1
    fi
    rm -rf "$TEMP"
fi
if [ $fatta -eq 0 ] && [ -f "$ICNS_PRONTA" ]; then
    cp "$ICNS_PRONTA" "$ICNS" && fatta=1
fi
[ $fatta -eq 0 ] && echo "Attenzione: non sono riuscito a preparare l'icona, l'app avrà quella generica."

touch "$APP"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" >/dev/null 2>&1

echo "Fatto: in ~/Applications c'è \"$NOME\" con il logo TAUH."
echo "Apre il programma che sta in: $QUI"
echo

# --- Dock ----------------------------------------------------------------------------
if defaults read com.apple.dock persistent-apps 2>/dev/null | grep -q "$NOME.app"; then
    echo "È già nel Dock (se l'icona non cambia, toglila e rimettila)."
else
    read -k 1 "risposta?La metto nel Dock adesso? [s/n] "
    echo
    case "$risposta" in
        s|S|y|Y)
            defaults write com.apple.dock persistent-apps -array-add \
                "<dict><key>tile-data</key><dict><key>file-data</key><dict><key>_CFURLString</key><string>file://$APP/</string><key>_CFURLStringType</key><integer>15</integer></dict></dict></dict>" \
                && killall Dock 2>/dev/null
            echo "Fatto: l'icona è nel Dock (il Dock si riavvia un attimo)."
            ;;
        *)
            echo "Va bene. Per metterla a mano: trascina l'app dal Finder nel Dock."
            open -R "$APP"
            ;;
    esac
fi
pausa
