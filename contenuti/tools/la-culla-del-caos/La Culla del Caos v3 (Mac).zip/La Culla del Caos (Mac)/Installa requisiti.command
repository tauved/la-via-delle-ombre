#!/bin/zsh
# Da lanciare una volta sola: strumenti Xcode (danno Python 3), Homebrew e FFmpeg.
# yt-dlp, Deno e numpy li installa poi da solo il programma alla prima apertura.

echo "LA CULLA DEL CAOS - installazione dei requisiti (macOS)"
echo "======================================================="
echo

pausa() {
    echo
    read -k 1 -s "risposta?Premi un tasto per chiudere questa finestra. "
    echo
}

# 1. Python 3: lo danno gli strumenti a riga di comando di Xcode (gratis, di Apple)
if /usr/bin/xcode-select -p >/dev/null 2>&1; then
    echo "Strumenti Xcode (Python 3): già installati."
else
    echo "Installo gli strumenti a riga di comando di Xcode, che danno Python 3."
    echo "Si apre una finestra di macOS: premi Installa, accetta la licenza e aspetta"
    echo "che finisca (qualche minuto). Poi rilancia questo file per il resto."
    /usr/bin/xcode-select --install
    pausa; exit 0
fi
echo

# 2. Homebrew: serve per FFmpeg
trova_brew() {
    local p
    for p in /opt/homebrew/bin/brew /usr/local/bin/brew; do
        [ -x "$p" ] && { echo "$p"; return 0; }
    done
    command -v brew 2>/dev/null
}
BREW=$(trova_brew)
if [ -n "$BREW" ]; then
    echo "Homebrew: già installato."
else
    echo "Homebrew non c'è: è il programma che installa FFmpeg (gratis, da brew.sh)."
    echo "L'installazione chiede la password del Mac e ci mette qualche minuto."
    read -k 1 "risposta?Lo installo adesso? [s/n] "
    echo
    case "$risposta" in
        s|S|y|Y)
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
            BREW=$(trova_brew)
            if [ -z "$BREW" ]; then
                echo
                echo "Homebrew non risulta installato. Riprova, oppure installalo seguendo le"
                echo "istruzioni su https://brew.sh e poi rilancia questo file."
                pausa; exit 1
            fi
            ;;
        *)
            echo "Va bene. Senza Homebrew installa FFmpeg come preferisci e mettilo nel PATH;"
            echo "La Culla del Caos lo cerca anche in /opt/homebrew/bin e /usr/local/bin."
            pausa; exit 0
            ;;
    esac
fi
eval "$("$BREW" shellenv)" 2>/dev/null
echo

# 3. FFmpeg
if command -v ffmpeg >/dev/null 2>&1; then
    echo "FFmpeg: già installato ($(command -v ffmpeg))."
else
    echo "Installo FFmpeg con Homebrew (ci vuole qualche minuto)..."
    HOMEBREW_NO_ENV_HINTS=1 "$BREW" install ffmpeg
    if command -v ffmpeg >/dev/null 2>&1; then
        echo "FFmpeg: installato."
    else
        echo "FFmpeg non risulta installato: riprova più tardi con   brew install ffmpeg"
        pausa; exit 1
    fi
fi
echo
echo "Fatto. Ora apri \"La Culla del Caos.command\" (tasto destro > Apri la prima volta),"
echo "oppure \"Metti nel Dock.command\" per avere l'icona nel Dock."
pausa
