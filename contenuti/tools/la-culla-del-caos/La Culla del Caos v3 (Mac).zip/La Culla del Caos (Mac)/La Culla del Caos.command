#!/bin/zsh
# La Culla del Caos - TAUH (macOS). Doppio clic per aprire la finestra.
# Cerca Python 3 (strumenti Xcode, Homebrew, python.org), avvia "La Culla del
# Caos.py" staccato dal Terminale e prova a chiudere questa finestra.

QUI="${0:A:h}"
PROGRAMMA="$QUI/La Culla del Caos.py"
LOG="$HOME/Library/Application Support/ScaricaWAV/interfaccia.log"

python_va_bene() {
    [ -x "$1" ] && "$1" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1
}

trova_python() {
    local p
    # 1. Python degli strumenti a riga di comando di Xcode (solo se sono installati:
    #    altrimenti /usr/bin/python3 è un finto eseguibile che apre una finestra)
    if /usr/bin/xcode-select -p >/dev/null 2>&1 && python_va_bene /usr/bin/python3; then
        echo /usr/bin/python3; return 0
    fi
    # 2. Homebrew (Apple Silicon, poi Intel)
    for p in /opt/homebrew/bin/python3 /usr/local/bin/python3; do
        python_va_bene "$p" && { echo "$p"; return 0; }
    done
    # 3. python.org, dalla versione più recente
    for p in /Library/Frameworks/Python.framework/Versions/*/bin/python3(NOn); do
        python_va_bene "$p" && { echo "$p"; return 0; }
    done
    # 4. quello che c'è nel PATH
    p=$(command -v python3 2>/dev/null)
    [ -n "$p" ] && python_va_bene "$p" && { echo "$p"; return 0; }
    return 1
}

pausa() {
    echo
    read -k 1 -s "risposta?Premi un tasto per chiudere questa finestra. "
    echo
}

if [ ! -f "$PROGRAMMA" ]; then
    echo "Non trovo \"La Culla del Caos.py\": tieni questo file nella stessa cartella."
    pausa; exit 1
fi

PY=$(trova_python)
if [ -z "$PY" ]; then
    cat <<'FINE'
Non trovo Python 3, che serve per far girare La Culla del Caos.
Installalo in uno di questi due modi, poi riapri questo file:

  1. Strumenti di Xcode (consigliato, gratis, di Apple): apri il Terminale e scrivi
        xcode-select --install
     poi premi Installa nella finestra che compare e aspetta che finisca.

  2. Oppure scarica Python 3 da https://www.python.org/downloads/macos/
     e installalo come un'app qualsiasi.
FINE
    pausa; exit 1
fi

mkdir -p "${LOG:h}" 2>/dev/null

# Avvio in una sessione nuova (setsid), così il programma resta vivo anche quando
# questa finestra si chiude e il Terminale non chiede "terminare i processi?".
"$PY" - "$PROGRAMMA" "$LOG" <<'FINE'
import subprocess, sys
with open(sys.argv[2], "ab") as log:
    subprocess.Popen([sys.executable, sys.argv[1]], stdin=subprocess.DEVNULL,
                     stdout=log, stderr=log, start_new_session=True)
FINE
if [ $? -ne 0 ]; then
    echo "Non sono riuscito ad avviare il programma. Prova dal Terminale:"
    echo "    \"$PY\" \"$PROGRAMMA\""
    pausa; exit 1
fi

echo "La Culla del Caos si sta aprendo. Puoi chiudere questa finestra."

# Chiudo la finestra del Terminale che ha lanciato questo file (solo quella).
if [ "$TERM_PROGRAM" = "Apple_Terminal" ]; then
    osascript -e 'tell application "Terminal" to close (every window whose name contains "La Culla del Caos")' >/dev/null 2>&1 &
fi
exit 0
