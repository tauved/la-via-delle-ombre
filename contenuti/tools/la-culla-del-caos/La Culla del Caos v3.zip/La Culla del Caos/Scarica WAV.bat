@echo off
rem Doppio clic e incolla i link, oppure trascina qui sopra un file .txt con i link.
setlocal
set "SCRIPT=%~dp0scarica_wav.py"
set "PYCMD="
where py >nul 2>nul && set "PYCMD=py -3"
if not defined PYCMD if exist "%LOCALAPPDATA%\Programs\Python\Launcher\py.exe" set "PYCMD="%LOCALAPPDATA%\Programs\Python\Launcher\py.exe" -3"
if not defined PYCMD where python >nul 2>nul && set "PYCMD=python"
if not defined PYCMD (
    echo Python non trovato. Lancia prima "Installa requisiti.bat" e poi riavvia il PC.
    goto fine
)
%PYCMD% "%SCRIPT%" %*
:fine
echo.
pause
