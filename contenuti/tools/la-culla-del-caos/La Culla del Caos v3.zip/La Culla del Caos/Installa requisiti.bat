@echo off
rem Da lanciare una volta sola: installa Python e FFmpeg con winget.
rem yt-dlp e Deno li installa poi da solo "Scarica WAV.bat" alla prima apertura.
setlocal
where winget >nul 2>nul
if errorlevel 1 (
    echo Non trovo winget. Installa "Programma di installazione app" dal Microsoft Store e riprova.
    goto fine
)

py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
if errorlevel 1 (
    echo Installo Python 3.13...
    winget install -e --id Python.Python.3.13 --accept-package-agreements --accept-source-agreements
) else (
    echo Python: gia' installato.
)
echo.

where ffmpeg >nul 2>nul
if errorlevel 1 (
    echo Installo FFmpeg...
    winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements
) else (
    echo FFmpeg: gia' installato.
)
echo.
echo Fatto. Se hai appena installato qualcosa, riavvia il PC e poi usa "Scarica WAV.bat".

:fine
echo.
pause
