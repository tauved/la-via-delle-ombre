r"""
La Culla del Caos - interfaccia grafica TAUH.

Doppio clic su questo file (o sul collegamento "La Culla del Caos" sul desktop) per
aprire la finestra. Ha due schede:
- Scarica: passa i link a scarica_wav.py, che deve stare nella stessa
  cartella, e mostra cosa succede;
- Converti: trasforma in MP3 o WAV qualsiasi file audio (anche le note
  vocali di WhatsApp) o l'audio di un video, con FFmpeg.

Usa solo quello che hai già installato con "Installa requisiti.bat" (Python e
FFmpeg). La finestra è una pagina locale aperta con Microsoft Edge in modalità
app, senza barra degli indirizzi; se Edge manca usa il browser predefinito.
Resta tutto sul tuo PC: il server ascolta solo su 127.0.0.1.

Per vedere gli errori, da terminale:  py "La Culla del Caos.pyw"
Opzioni di prova:  --nessuna-finestra  --porta N
"""

from __future__ import annotations

import collections
import csv
import io
import json
import os
import queue
import re
import secrets
import shutil
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

NOME_SCRIPT = "scarica_wav.py"
PORTA_PREDEFINITA = 47616
MAX_LINK = 100

QUI = Path(__file__).resolve().parent
WEB = QUI / "interfaccia"
DATI = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / ".local" / "share")) / "ScaricaWAV"
FILE_IMPOSTAZIONI = DATI / "interfaccia.json"
FILE_ISTANZA = DATI / "interfaccia_in_uso.json"
FILE_LOG = DATI / "interfaccia.log"

SU_WINDOWS = os.name == "nt"
SENZA_CONSOLE = 0x08000000 if SU_WINDOWS else 0  # CREATE_NO_WINDOW

CAMPI_REGISTRO = ["data", "file", "titolo", "artista_o_canale", "link",
                  "link_acquisto_download", "bpm", "tonalita"]
URL_RE = re.compile(r"https?://[^\s<>\"'()\[\]{}|;]+", re.I)
NEGOZI = {
    "beatstars.com": "BeatStars", "bsta.rs": "BeatStars", "airbit.com": "Airbit",
    "traktrain.com": "Traktrain", "soundee.com": "Soundee", "beatbrokerz.com": "BeatBrokerz",
    "gumroad.com": "Gumroad", "payhip.com": "Payhip", "bandcamp.com": "Bandcamp",
    "soundclick.com": "SoundClick", "drive.google.com": "Google Drive",
    "dropbox.com": "Dropbox", "mega.nz": "MEGA", "wetransfer.com": "WeTransfer",
    "linktr.ee": "Linktree", "untitled.stream": "untitled",
}

# Righe stampate da scarica_wav.py
RE_TITOLO = re.compile(r"^>\s?(.*)$")
RE_PERCENTUALE = re.compile(r"scarico\.\.\.\s*(\d{1,3})\s*%", re.I)
RE_CONVERTO = re.compile(r"converto in wav", re.I)
RE_SALTATO = re.compile(r"^\s*gi(?:à|a')\s+scaricato,\s*lo\s+salto", re.I)  # non il riepilogo finale
RE_ERRORE = re.compile(r"^\s*errore:\s*(.*)$", re.I)
RE_ERRORE_CONVERSIONE = re.compile(r"postprocess|ffmpeg|ffprobe|conver", re.I)
RE_AVVISO = re.compile(r"^\s*avviso:\s*(.*)$", re.I)
RE_SALVATO = re.compile(r"^\s*salvat[oi]\b", re.I)
RE_EXCEL = re.compile(r"(?:è|e')\s+aperto", re.I)
RE_PREPARO = re.compile(r"^(installo|aggiorno|controllo|scarico deno|aggiornamento)\b", re.I)
RE_DENO = re.compile(r"non trovo deno", re.I)


# --- Utilità -------------------------------------------------------------------

def prepara_log():
    """Con pythonw non c'è console: i messaggi finiscono in un file di log."""
    try:
        DATI.mkdir(parents=True, exist_ok=True)
        if FILE_LOG.exists() and FILE_LOG.stat().st_size > 1_000_000:
            FILE_LOG.unlink()
        if sys.stdout is None or sys.stderr is None:
            f = open(FILE_LOG, "a", encoding="utf-8", buffering=1)
            if sys.stdout is None:
                sys.stdout = f
            if sys.stderr is None:
                sys.stderr = f
    except OSError:
        pass


def scrivi_json(percorso, dati):
    try:
        percorso.parent.mkdir(parents=True, exist_ok=True)
        provvisorio = percorso.with_suffix(".tmp")
        provvisorio.write_text(json.dumps(dati, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(provvisorio, percorso)
    except OSError as e:
        print(f"Non riesco a salvare {percorso.name}: {e}")


def leggi_json(percorso):
    try:
        dati = json.loads(percorso.read_text(encoding="utf-8"))
        return dati if isinstance(dati, dict) else {}
    except (OSError, ValueError):
        return {}


def python_console():
    """python.exe accanto a pythonw.exe: serve per avere l'output dello script."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        alternativo = exe.with_name("python.exe")
        if alternativo.exists():
            return str(alternativo)
    return str(exe)


def trova_script(impostazioni):
    candidati = []
    if impostazioni.get("script"):
        candidati.append(Path(impostazioni["script"]))
    candidati += [QUI / NOME_SCRIPT, QUI.parent / NOME_SCRIPT]
    for c in candidati:
        if c.is_file():
            return c
    return None


def predefiniti(script):
    """Legge da scarica_wav.py le impostazioni scritte in cima (senza eseguirlo)."""
    frequenza, bit = 44100, 16
    cartella = Path.home() / "Music" / "Beat per provini"
    registro = "registro_beat.csv"
    testo = ""
    if script:
        try:
            testo = script.read_text(encoding="utf-8", errors="replace")
        except OSError:
            pass
    if m := re.search(r"^FREQUENZA\s*=\s*(\d+)", testo, re.M):
        frequenza = int(m.group(1))
    if m := re.search(r"^BIT\s*=\s*(\d+)", testo, re.M):
        bit = int(m.group(1))
    if m := re.search(r'^REGISTRO\s*=\s*"([^"]+)"', testo, re.M):
        registro = m.group(1)
    if m := re.search(r"^CARTELLA\s*=\s*(.+)$", testo, re.M):
        espressione = m.group(1).split("#")[0].strip()
        parti = re.findall(r'"([^"]*)"', espressione)
        if espressione.startswith("Path.home()"):
            cartella = Path.home().joinpath(*parti)
        elif m2 := re.match(r'Path\(\s*r?"([^"]+)"\s*\)', espressione):
            cartella = Path(m2.group(1)).joinpath(*parti[1:])
    return frequenza, bit, cartella, registro


def apri_con_sistema(percorso):
    if SU_WINDOWS:
        os.startfile(str(percorso))
    elif shutil.which("xdg-open"):
        subprocess.Popen(["xdg-open", str(percorso)])
    elif shutil.which("open"):
        subprocess.Popen(["open", str(percorso)])


def nome_negozio(url):
    host = (urlparse(url).hostname or "").lower().removeprefix("www.")
    for dominio, nome in NEGOZI.items():
        if host == dominio or host.endswith("." + dominio):
            return nome
    return host or "link"


def errore_leggibile(msg):
    m = msg.lower()
    if "sign in to confirm your age" in m or "age-restricted" in m or "inappropriate" in m:
        return "Video con limite d'età: YouTube chiede l'accesso."
    if "not a bot" in m:
        return "YouTube chiede di confermare che non sei un bot: riprova tra un po'."
    if "private video" in m:
        return "Il video è privato."
    if "video unavailable" in m or "not available" in m or "has been removed" in m:
        return "Video non disponibile: rimosso, privato o bloccato nel tuo paese."
    if "unsupported url" in m or "is not a valid url" in m:
        return "Link non supportato."
    if "http error 403" in m or "forbidden" in m:
        return "YouTube ha bloccato il download (errore 403). Riprova: alla prossima apertura yt-dlp si aggiorna."
    if "http error 429" in m or "too many requests" in m:
        return "Troppe richieste a YouTube: aspetta qualche minuto e riprova."
    if "ffmpeg" in m or "ffprobe" in m:
        return "FFmpeg non trovato: lancia «Installa requisiti.bat» e riavvia il PC."
    if "unable to download" in m or "connection" in m or "timed out" in m or "getaddrinfo" in m:
        return "Problema di connessione: controlla internet e riprova."
    return msg if len(msg) <= 220 else msg[:217] + "…"


# --- Registro dei beat -----------------------------------------------------------

def leggi_registro(cartella, nome):
    percorso = cartella / nome
    if not percorso.is_file():
        return [], None
    try:
        testo = percorso.read_text(encoding="utf-8-sig", errors="replace")
    except PermissionError:
        return [], "Non riesco a leggere il registro: è aperto in un altro programma."
    except OSError as e:
        return [], f"Non riesco a leggere il registro: {e}"
    righe = [r for r in csv.reader(io.StringIO(testo), delimiter=";") if any(c.strip() for c in r)]
    if not righe:
        return [], None
    intestazione = [c.strip().lower() for c in righe[0]]
    if "titolo" in intestazione:
        righe = righe[1:]
    else:
        intestazione = CAMPI_REGISTRO
    voci = []
    for n, riga in enumerate(righe):
        d = {k: (riga[i].strip() if i < len(riga) else "") for i, k in enumerate(intestazione)}
        nome_file = d.get("file", "")
        percorso_file = Path(nome_file) if nome_file else None
        if percorso_file and not percorso_file.is_absolute():
            percorso_file = cartella / percorso_file
        acquisto = []
        for url in URL_RE.findall(d.get("link_acquisto_download", "")):
            url = url.rstrip(".,")
            nome = nome_negozio(url)
            if all(a["url"] != url and a["nome"] != nome for a in acquisto):
                acquisto.append({"url": url, "nome": nome})
        voci.append({
            "n": n,
            "data": d.get("data", ""),
            "file": nome_file,
            "esiste": bool(percorso_file and percorso_file.is_file()),
            "titolo": d.get("titolo", "") or Path(nome_file).stem,
            "artista": d.get("artista_o_canale", ""),
            "link": d.get("link", "") if d.get("link", "").startswith("http") else "",
            "acquisto": acquisto[:4],
            "bpm": d.get("bpm", ""),
            "tonalita": d.get("tonalita", ""),
        })
    voci.reverse()
    return voci[:500], None


def conta_registro(cartella, nome):
    voci, _ = leggi_registro(cartella, nome)
    return len(voci)


def aggiorna_registro(cartella, nome, nome_file, bpm, tonalita):
    """Scrive BPM e tonalità nella riga del registro che ha quel file; True se ha scritto."""
    percorso = cartella / nome
    if not percorso.is_file():
        return False, "Il registro non c'è."
    try:
        testo = percorso.read_text(encoding="utf-8-sig", errors="replace")
    except OSError as e:
        return False, f"Non riesco a leggere il registro: {e}"
    righe = list(csv.reader(io.StringIO(testo), delimiter=";"))
    if not righe:
        return False, "Il registro è vuoto."
    intestazione = [c.strip().lower() for c in righe[0]]
    if "titolo" not in intestazione:
        righe.insert(0, list(CAMPI_REGISTRO))
        intestazione = list(CAMPI_REGISTRO)
    for campo in ("bpm", "tonalita"):
        if campo not in intestazione:
            intestazione.append(campo)
            righe[0].append(campo)
    i_file, i_bpm, i_ton = intestazione.index("file"), intestazione.index("bpm"), intestazione.index("tonalita")
    trovata = False
    for riga in righe[1:]:
        if len(riga) <= i_file or riga[i_file].strip() != nome_file:
            continue
        while len(riga) < len(intestazione):
            riga.append("")
        if bpm and not riga[i_bpm].strip():
            riga[i_bpm] = str(bpm)
        if tonalita and not riga[i_ton].strip():
            riga[i_ton] = tonalita
        trovata = True
    if not trovata:
        return False, "Il file non è nel registro."
    try:
        provvisorio = percorso.with_suffix(".tmp")
        with provvisorio.open("w", newline="", encoding="utf-8-sig") as f:
            csv.writer(f, delimiter=";").writerows(righe)
        os.replace(provvisorio, percorso)
    except PermissionError:
        return False, "Il registro è aperto in Excel: chiudilo e riprova."
    except OSError as e:
        return False, f"Non riesco a scrivere il registro: {e}"
    return True, None


# --- Un giro di download -------------------------------------------------------------

class Lavoro:
    def __init__(self, app, numero, link, cartella, freq48, bit24):
        self.app = app
        self.numero = numero
        self.link = link
        self.cartella = cartella
        self.freq48 = freq48
        self.bit24 = bit24
        self.voci = []
        self.corrente = None
        self.stato = "in_corso"
        self.fase = "Avvio La Culla del Caos…"
        self.avviso = ""
        self.codice = None
        self.nuovi = 0
        self.proc = None
        self.annullato = False
        self.inizio = time.time()
        self.fine = None
        self.ultima_riga = ""

    def istantanea(self):
        conteggi = collections.Counter(v["stato"] for v in self.voci)
        return {
            "numero": self.numero,
            "stato": self.stato,
            "fase": self.fase,
            "avviso": self.avviso,
            "n_link": len(self.link),
            "voci": [dict(v) for v in self.voci],
            "salvati": conteggi["salvato"],
            "saltati": conteggi["saltato"],
            "errori": conteggi["errore"],
            "codice": self.codice,
            "nuovi": self.nuovi,
            "durata": round((self.fine or time.time()) - self.inizio),
        }

    # Lettura dell'output -----------------------------------------------------

    def _voce(self, titolo, stato="scarico"):
        voce = {"id": len(self.voci) + 1, "titolo": titolo or "Senza titolo",
                "stato": stato, "pct": 0, "msg": "", "dettaglio": ""}
        self.voci.append(voce)
        return voce

    def _chiudi_corrente(self, stato="salvato"):
        v = self.corrente
        if v and v["stato"] in ("scarico", "converto"):
            v["stato"] = stato
            if stato == "salvato":
                v["pct"] = 100
        self.corrente = None

    def riga(self, testo):
        testo = testo.rstrip()
        pulito = testo.strip()
        if not pulito:
            return
        if not RE_PERCENTUALE.search(testo):
            self.app.registra_log(testo)
            self.ultima_riga = pulito
        if m := RE_TITOLO.match(pulito):
            self._chiudi_corrente()
            self.corrente = self._voce(m.group(1).strip())
            self.fase = ""
        elif m := RE_PERCENTUALE.search(testo):
            if not self.corrente:
                self.corrente = self._voce("")
            self.corrente["pct"] = max(0, min(100, int(m.group(1))))
            self.corrente["stato"] = "scarico"
        elif RE_CONVERTO.search(testo):
            if self.corrente:
                self.corrente["stato"] = "converto"
                self.corrente["pct"] = 100
        elif RE_SALTATO.search(testo):
            if self.corrente and self.corrente["stato"] == "scarico" and self.corrente["pct"] == 0:
                self.corrente["stato"] = "saltato"
                self.corrente["pct"] = 100
                self.corrente = None
        elif m := RE_ERRORE.match(testo):
            messaggio = m.group(1).strip()
            v = self.corrente
            if v and (v["stato"] == "converto" or v["pct"] >= 100) and not RE_ERRORE_CONVERSIONE.search(messaggio):
                # il brano prima è già scaricato: l'errore è del link successivo,
                # che non ha stampato il titolo perché non è mai partito
                self._chiudi_corrente()
                v = None
            elif v and v["stato"] not in ("scarico", "converto"):
                v = None
            if v is None:
                if any(x["stato"] == "errore" and x["dettaglio"] == messaggio for x in self.voci):
                    self.app.cambiato()
                    return  # lo stesso errore ripetuto nel riepilogo finale
                v = self._voce("Link non scaricato", "errore")
            v["stato"] = "errore"
            v["msg"] = errore_leggibile(messaggio)
            v["dettaglio"] = messaggio
            self.corrente = None
        elif RE_AVVISO.match(testo):
            pass
        elif RE_SALVATO.match(testo):
            if self.corrente:
                self._chiudi_corrente()
        elif RE_EXCEL.search(testo):
            self.avviso = "Il registro è aperto in Excel: chiudilo, così La Culla del Caos può aggiornarlo."
        elif RE_DENO.search(testo):
            self.avviso = "Manca Deno: senza YouTube spesso non funziona. Riapri La Culla del Caos per installarlo."
        elif RE_PREPARO.match(pulito):
            self.fase = pulito.rstrip(".").rstrip("…") + "…"
        self.app.cambiato()

    def riga_parziale(self, testo):
        if (m := RE_PERCENTUALE.search(testo)) and self.corrente:
            pct = max(0, min(100, int(m.group(1))))
            if pct != self.corrente["pct"]:
                self.corrente["pct"] = pct
                self.app.cambiato()

    # Esecuzione --------------------------------------------------------------

    def esegui(self):
        script = self.app.script
        comando = [python_console(), "-u", str(script)]
        if self.freq48:
            comando.append("--48k")
        if self.bit24:
            comando.append("--24bit")
        comando += ["--cartella", str(self.cartella), *self.link]
        ambiente = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1"}
        prima = conta_registro(self.cartella, self.app.nome_registro)
        try:
            self.proc = subprocess.Popen(
                comando, cwd=str(script.parent), stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=ambiente,
                creationflags=SENZA_CONSOLE, start_new_session=not SU_WINDOWS)
        except OSError as e:
            self.stato = "errore"
            self.fase = f"Non riesco ad avviare scarica_wav.py: {e}"
            self.fine = time.time()
            self.app.fine_lavoro(self)
            return

        resto = b""
        while True:
            pezzo = self.proc.stdout.read1(4096)
            if not pezzo:
                break
            resto += pezzo
            parti = re.split(rb"[\r\n]", resto)
            resto = parti.pop()
            for parte in parti:
                self.riga(parte.decode("utf-8", "replace"))
            if resto:
                self.riga_parziale(resto.decode("utf-8", "replace"))
        if resto:
            self.riga(resto.decode("utf-8", "replace"))
        self.codice = self.proc.wait()

        if self.annullato:
            self._chiudi_corrente("annullato")
            self.stato = "annullato"
            self.fase = "Annullato."
        else:
            self._chiudi_corrente()
            errori = sum(v["stato"] == "errore" for v in self.voci)
            if self.codice not in (0, None) and not errori:
                v = self._voce("Qualcosa non è andato", "errore")
                v["msg"] = errore_leggibile(self.ultima_riga or f"scarica_wav.py si è chiuso con il codice {self.codice}.")
                v["dettaglio"] = self.ultima_riga
            self.stato = "finito"
            self.fase = ""
        self.nuovi = max(0, conta_registro(self.cartella, self.app.nome_registro) - prima)
        self.fine = time.time()
        self.app.fine_lavoro(self)

    def annulla(self):
        self.annullato = True
        p = self.proc
        if p is None or p.poll() is not None:
            return
        try:
            if SU_WINDOWS:
                subprocess.run(["taskkill", "/PID", str(p.pid), "/T", "/F"],
                               capture_output=True, creationflags=SENZA_CONSOLE)
            else:
                os.killpg(p.pid, signal.SIGTERM)
        except (OSError, subprocess.SubprocessError):
            p.kill()


# --- Conversione audio ---------------------------------------------------------------------

CARTELLA_CONVERTITI = Path.home() / "Music" / "Convertiti"
TEMP_CONV = DATI / "conversione"
MAX_FILE_CONV = 4 * 1024 ** 3
MAX_CODA = 500
KBPS_MP3 = (320, 192, 128)
ESTENSIONI_AUDIO = {
    ".mp3", ".wav", ".wave", ".opus", ".ogg", ".oga", ".waptt", ".m4a", ".m4b", ".aac", ".amr",
    ".awb", ".3gp", ".3ga", ".3g2", ".wma", ".flac", ".aif", ".aiff", ".aifc", ".caf", ".webm",
    ".weba", ".mka", ".mkv", ".mp4", ".m4v", ".mov", ".avi", ".ac3", ".eac3", ".dts", ".mp2",
    ".mpga", ".wv", ".ape", ".alac", ".au", ".snd", ".spx", ".mpeg", ".mpg", ".ts", ".flv",
}
RE_WHATSAPP = re.compile(r"whatsapp|^ptt-|^aud-\d{8}-wa\d+|-wa\d{4}|\.waptt$", re.I)
CARATTERI_VIETATI = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
NOMI_RISERVATI = {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)),
                  *(f"LPT{i}" for i in range(1, 10))}
NOMI_CODEC = {
    "opus": "Opus", "vorbis": "Vorbis", "aac": "AAC", "mp3": "MP3", "mp2": "MP2", "flac": "FLAC",
    "alac": "ALAC", "wmav1": "WMA", "wmav2": "WMA", "wmapro": "WMA Pro", "wmalossless": "WMA Lossless",
    "amr_nb": "AMR", "amr_wb": "AMR-WB", "ac3": "AC3", "eac3": "E-AC3", "dts": "DTS", "speex": "Speex",
    "wavpack": "WavPack", "ape": "APE",
}


def trova_ffmpeg():
    if percorso := shutil.which("ffmpeg"):
        return percorso
    base = os.environ.get("LOCALAPPDATA")
    if SU_WINDOWS and base:  # collegamenti creati da winget
        candidato = Path(base) / "Microsoft" / "WinGet" / "Links" / "ffmpeg.exe"
        if candidato.is_file():
            return str(candidato)
    return None


def trova_ffprobe(ffmpeg):
    if percorso := shutil.which("ffprobe"):
        return percorso
    if ffmpeg:
        candidato = Path(ffmpeg).with_name("ffprobe.exe" if SU_WINDOWS else "ffprobe")
        if candidato.is_file():
            return str(candidato)
    return None


def nome_sicuro(nome, ripiego="audio"):
    """Nome di file valido su Windows, senza cartelle."""
    nome = str(nome).replace("\\", "/").rsplit("/", 1)[-1]
    nome = CARATTERI_VIETATI.sub("_", nome).strip().rstrip(". ")
    if not nome or nome.split(".")[0].upper() in NOMI_RISERVATI:
        nome = f"{ripiego}{Path(nome).suffix if nome else ''}"
    if len(nome) > 150:
        coda = Path(nome).suffix[:12]
        nome = nome[:150 - len(coda)].rstrip(". ") + coda
    return nome


def radice_nome(nome):
    """'PTT-20161001-WA0001.aac.waptt' -> 'PTT-20161001-WA0001'."""
    radice = nome
    while Path(radice).suffix.lower() in ESTENSIONI_AUDIO and Path(radice).stem:
        radice = Path(radice).stem
    return nome_sicuro(radice, "audio")


def nome_libero(cartella, radice, estensione):
    candidato = cartella / f"{radice}{estensione}"
    n = 2
    while candidato.exists():
        candidato = cartella / f"{radice} ({n}){estensione}"
        n += 1
    return candidato


def _numero(valore):
    try:
        numero = float(valore)
    except (TypeError, ValueError):
        return None
    return numero if 0 < numero < 1e7 else None


def nome_codec(codec, formato):
    codec = (codec or "").lower()
    if codec.startswith("pcm_"):
        contenitore = (formato or "").split(",")[0].lower()
        return {"wav": "WAV", "w64": "WAV", "aiff": "AIFF", "caf": "CAF"}.get(contenitore, "PCM")
    return NOMI_CODEC.get(codec, codec.upper() or "?")


def analizza_audio(ffmpeg, ffprobe, percorso):
    """Ritorna (info, errore); info = {"codec", "durata", "video"}."""
    if ffprobe:
        try:
            risultato = subprocess.run(
                [ffprobe, "-v", "error", "-of", "json", "-show_entries",
                 "format=duration,format_name:stream=codec_type,codec_name,duration"
                 ":stream_disposition=attached_pic", str(percorso)],
                capture_output=True, timeout=60, creationflags=SENZA_CONSOLE)
            dati = json.loads(risultato.stdout.decode("utf-8", "replace") or "{}")
        except (OSError, subprocess.SubprocessError, ValueError):
            dati = None
        if isinstance(dati, dict):
            flussi = dati.get("streams") or []
            formato = dati.get("format") or {}
            if not flussi and not formato:
                return None, "Formato non riconosciuto: non è un file audio o è danneggiato."
            audio = [s for s in flussi if s.get("codec_type") == "audio"]
            if not audio:
                return None, "Il file non contiene audio."
            video = any(s.get("codec_type") == "video" and not (s.get("disposition") or {}).get("attached_pic")
                        for s in flussi)
            return {"codec": nome_codec(audio[0].get("codec_name"), formato.get("format_name")),
                    "durata": _numero(formato.get("duration")) or _numero(audio[0].get("duration")),
                    "video": video}, None
    if not ffmpeg:
        return None, "FFmpeg non trovato: lancia «Installa requisiti.bat» e riavvia il PC."
    try:  # senza ffprobe: leggo quello che FFmpeg scrive del file
        risultato = subprocess.run([ffmpeg, "-hide_banner", "-nostdin", "-i", str(percorso)],
                                   capture_output=True, timeout=60, creationflags=SENZA_CONSOLE)
    except (OSError, subprocess.SubprocessError) as e:
        return None, f"Non riesco ad analizzare il file: {e}"
    testo = risultato.stderr.decode("utf-8", "replace")
    audio = re.search(r"Stream #\S+.*?: Audio: (\w+)", testo)
    if not audio:
        if "Stream #" in testo:
            return None, "Il file non contiene audio."
        return None, "Formato non riconosciuto: non è un file audio o è danneggiato."
    durata = None
    if m := re.search(r"Duration: (\d+):(\d+):(\d+(?:\.\d+)?)", testo):
        durata = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    contenitore = re.search(r"Input #0, ([\w,]+), from", testo)
    video = any("attached pic" not in riga for riga in re.findall(r"Stream #\S+.*?: Video: .*", testo))
    return {"codec": nome_codec(audio.group(1), contenitore.group(1) if contenitore else ""),
            "durata": durata, "video": video}, None


def errore_ffmpeg(testo):
    t = testo.lower()
    if "matches no streams" in t or "does not contain any stream" in t:
        return "Il file non contiene audio."
    if "invalid data found" in t or "moov atom not found" in t or "could not find codec parameters" in t:
        return "File danneggiato o formato non riconosciuto."
    if "unknown encoder" in t or "encoder not found" in t:
        return "Questo FFmpeg non sa creare questo formato: reinstallalo con «Installa requisiti.bat»."
    if "permission denied" in t:
        return "Permesso negato: il file è aperto in un altro programma o la cartella è protetta."
    if "no space left" in t:
        return "Disco pieno."
    if "no such file" in t:
        return "Il file non c'è più."
    righe = [r.strip() for r in testo.splitlines() if r.strip()]
    ultima = righe[-1] if righe else "FFmpeg si è fermato senza dire perché."
    return ultima if len(ultima) <= 200 else ultima[:197] + "…"


def elenco_convertiti(cartella, limite=200):
    voci = []
    try:
        with os.scandir(cartella) as elementi:
            for e in elementi:
                if e.is_file() and Path(e.name).suffix.lower() in (".mp3", ".wav"):
                    info = e.stat()
                    voci.append((info.st_mtime, e.name, info.st_size))
    except OSError:
        return []
    voci.sort(reverse=True)
    return [{"nome": nome, "percorso": str(cartella / nome), "formato": Path(nome).suffix[1:].upper(),
             "dimensione": dimensione, "data": time.strftime("%d/%m/%Y %H:%M", time.localtime(data))}
            for data, nome, dimensione in voci[:limite]]


def dentro_temp(percorso):
    try:
        return TEMP_CONV.resolve() in Path(percorso).resolve().parents
    except OSError:
        return False


class Convertitore:
    """Coda dei file da convertire, convertiti uno alla volta con FFmpeg."""

    def __init__(self, app):
        self.app = app
        self.voci = []
        self.prossimo = 1
        self.in_corso = False
        self.fermare = False
        self.proc = None
        self.caricamenti = 0
        self.numero_giro = 0
        self.giro = {"fatti": 0, "errori": 0}
        self.ultimi = []
        self.limite_analisi = threading.Semaphore(3)

    def istantanea(self):
        voci = [{k: v for k, v in voce.items() if k not in ("sorgente", "temp")} for voce in self.voci]
        da_fare = sum(v["stato"] in ("in_coda", "analisi", "converto") for v in self.voci) if self.in_corso else 0
        return {"in_corso": self.in_corso, "voci": voci, "caricamenti": self.caricamenti,
                "giro": {"numero": self.numero_giro, "da_fare": da_fare, **self.giro},
                "ultimi": list(self.ultimi)}

    # Elenco -------------------------------------------------------------------------

    def aggiungi(self, sorgente, nome, temporaneo, dimensione):
        with self.app.lock:
            if len(self.voci) >= MAX_CODA:
                return None, f"Al massimo {MAX_CODA} file nell'elenco: svuotalo e continua."
            voce = {"id": self.prossimo, "nome": nome, "sorgente": str(sorgente), "temp": temporaneo,
                    "stato": "analisi", "pct": 0, "msg": "", "dettaglio": "", "codec": "", "durata": None,
                    "video": False, "whatsapp": bool(RE_WHATSAPP.search(nome)), "dimensione": dimensione,
                    "uscita": "", "uscita_nome": ""}
            self.prossimo += 1
            self.voci.append(voce)
        threading.Thread(target=self._analizza, args=(voce,), daemon=True).start()
        self.app.cambiato()
        return voce, None

    def _analizza(self, voce):
        with self.limite_analisi:
            with self.app.lock:
                if voce not in self.voci:
                    return
            info, errore = analizza_audio(self.app.ffmpeg, self.app.ffprobe, Path(voce["sorgente"]))
        with self.app.lock:
            if voce not in self.voci:
                return
            if errore:
                voce.update(stato="errore", msg=errore)
            else:
                voce.update(stato="in_coda", codec=info["codec"], durata=info["durata"], video=info["video"])
        self.app.cambiato()

    def togli(self, ids=None):
        with self.app.lock:
            via = [v for v in self.voci if v["stato"] != "converto" and (ids is None or v["id"] in ids)]
            for v in via:
                self.voci.remove(v)
        for v in via:
            self._cancella_sorgente(v)
        self.app.cambiato()
        return len(via)

    def _cancella_sorgente(self, voce):
        if voce.get("temp") and dentro_temp(voce["sorgente"]):
            shutil.rmtree(Path(voce["sorgente"]).parent, ignore_errors=True)

    def di_nuovo(self):
        with self.app.lock:
            n = 0
            for v in self.voci:
                if v["stato"] == "fatto" and Path(v["sorgente"]).is_file():
                    v.update(stato="in_coda", pct=0, msg="", uscita="", uscita_nome="")
                    n += 1
        self.app.cambiato()
        return n

    # Conversione ----------------------------------------------------------------------

    def avvia(self):
        with self.app.lock:
            if self.in_corso:
                return "Sta già convertendo."
            if not self.app.ffmpeg:
                return "FFmpeg non trovato: lancia «Installa requisiti.bat» e riavvia il PC."
            if not any(v["stato"] in ("in_coda", "analisi") for v in self.voci):
                return "Nessun file da convertire."
            opzioni = self.app.opzioni_conv()
            try:
                opzioni["cartella"].mkdir(parents=True, exist_ok=True)
            except OSError as e:
                return f"Non riesco a creare la cartella {opzioni['cartella']}: {e}"
            self.in_corso = True
            self.fermare = False
            self.numero_giro += 1
            self.giro = {"fatti": 0, "errori": 0}
            self.ultimi = []
            threading.Thread(target=self._esegui, args=(opzioni,), daemon=True).start()
        self.app.cambiato()
        return None

    def ferma(self):
        with self.app.lock:
            if not self.in_corso:
                return
            self.fermare = True
            proc = self.proc
        if proc and proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass

    def _esegui(self, opzioni):
        try:
            while not self.fermare and not self.app.in_chiusura.is_set():
                with self.app.lock:
                    voce = next((v for v in self.voci if v["stato"] == "in_coda"), None)
                    in_analisi = any(v["stato"] == "analisi" for v in self.voci) or self.caricamenti > 0
                    if voce:
                        voce.update(stato="converto", pct=0, msg="", dettaglio="")
                if voce is None:
                    if in_analisi:
                        time.sleep(0.1)
                        continue
                    break
                self.app.cambiato()
                self._converti(voce, opzioni)
        finally:
            with self.app.lock:
                for v in self.voci:
                    if v["stato"] == "converto":  # annullato a metà: torna in coda
                        v.update(stato="in_coda", pct=0)
                self.in_corso = False
                self.proc = None
                fine = {"tipo": "fine_conv", "fatti": self.giro["fatti"], "errori": self.giro["errori"],
                        "annullato": self.fermare}
            self.app.invia(self.app.stato())
            self.app.invia(fine)

    def _converti(self, voce, opzioni):
        formato = opzioni["formato"]
        estensione = "." + formato
        try:
            TEMP_CONV.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            return self._errore(voce, f"Non riesco a preparare la conversione: {e}")
        parziale = TEMP_CONV / f"uscita-{voce['id']}-{secrets.token_hex(4)}{estensione}"
        comando = [self.app.ffmpeg, "-hide_banner", "-nostdin", "-loglevel", "error", "-y",
                   "-i", voce["sorgente"], "-map", "0:a:0", "-vn", "-sn", "-dn", "-map_metadata", "0",
                   "-progress", "pipe:1", "-nostats"]
        if formato == "mp3":
            comando += ["-c:a", "libmp3lame", "-b:a", f"{opzioni['kbps']}k", "-ar", "44100",
                        "-id3v2_version", "3", "-f", "mp3"]
        else:
            comando += ["-c:a", "pcm_s24le" if opzioni["bit24"] else "pcm_s16le",
                        "-ar", "48000" if opzioni["freq48"] else "44100", "-f", "wav"]
        comando.append(str(parziale))

        errori = collections.deque(maxlen=40)
        try:
            proc = subprocess.Popen(comando, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, creationflags=SENZA_CONSOLE)
        except OSError as e:
            return self._errore(voce, f"Non riesco ad avviare FFmpeg: {e}")
        with self.app.lock:
            self.proc = proc
        if self.fermare:
            proc.kill()

        def leggi_errori():
            for riga in proc.stderr:
                errori.append(riga.decode("utf-8", "replace").rstrip())
        lettore = threading.Thread(target=leggi_errori, daemon=True)
        lettore.start()

        durata = voce.get("durata")
        for riga in proc.stdout:
            chiave, _, valore = riga.decode("ascii", "replace").strip().partition("=")
            if chiave in ("out_time_us", "out_time_ms") and durata:
                try:
                    pct = int(int(valore) / (durata * 1e6) * 100)
                except ValueError:
                    continue
                pct = max(0, min(99, pct))
                if pct != voce["pct"]:
                    voce["pct"] = pct
                    self.app.cambiato()
        codice = proc.wait()
        lettore.join(timeout=2)
        with self.app.lock:
            self.proc = None

        if self.fermare:
            parziale.unlink(missing_ok=True)
            return None
        if codice != 0 or not parziale.is_file() or parziale.stat().st_size == 0:
            parziale.unlink(missing_ok=True)
            return self._errore(voce, errore_ffmpeg("\n".join(errori)), "\n".join(list(errori)[-6:]))

        cartella = opzioni["cartella"]
        try:
            cartella.mkdir(parents=True, exist_ok=True)
            destinazione = nome_libero(cartella, radice_nome(voce["nome"]), estensione)
            shutil.move(str(parziale), str(destinazione))
        except OSError as e:
            parziale.unlink(missing_ok=True)
            return self._errore(voce, f"Non riesco a salvare il file in {cartella}: {e}")
        with self.app.lock:
            voce.update(stato="fatto", pct=100, uscita=str(destinazione), uscita_nome=destinazione.name)
            self.giro["fatti"] += 1
            self.ultimi.append(str(destinazione))
        self.app.cambiato()
        return None

    def _errore(self, voce, messaggio, dettaglio=""):
        with self.app.lock:
            voce.update(stato="errore", msg=messaggio, dettaglio=dettaglio)
            self.giro["errori"] += 1
        self.app.cambiato()


# --- BPM e chiave --------------------------------------------------------------------------

NOME_MOTORE = "trova_bpm_chiave.py"
TEMP_ANALISI = DATI / "analisi"


def nome_chiave_lungo(corta):
    return corta


class Analizzatore:
    """Coda di file da analizzare con trova_bpm_chiave.py, uno alla volta."""

    def __init__(self, app):
        self.app = app
        self.voci = []
        self.prossimo = 1
        self.in_corso = False
        self.fermare = False
        self.proc = None
        self.caricamenti = 0
        self.fase = ""
        self.numpy_ok = None

    def istantanea(self):
        voci = [{k: v for k, v in voce.items() if k not in ("sorgente", "temp")} for voce in self.voci]
        return {"in_corso": self.in_corso, "voci": voci, "caricamenti": self.caricamenti, "fase": self.fase,
                "motore": (QUI / NOME_MOTORE).is_file()}

    def aggiungi(self, sorgente, nome, temporaneo, registro_file=None, dimensione=0):
        with self.app.lock:
            if len(self.voci) >= MAX_CODA:
                return None, f"Al massimo {MAX_CODA} file nell'elenco: svuotalo e continua."
            if registro_file and any(v.get("registro") == registro_file and v["stato"] != "errore" for v in self.voci):
                return None, "È già in elenco."
            voce = {"id": self.prossimo, "nome": nome, "sorgente": str(sorgente), "temp": temporaneo,
                    "registro": registro_file, "stato": "in_coda", "msg": "", "dettaglio": "",
                    "dimensione": dimensione, "risultato": None, "salvato": False}
            self.prossimo += 1
            self.voci.append(voce)
        self.app.cambiato()
        return voce, None

    def togli(self, ids=None):
        with self.app.lock:
            via = [v for v in self.voci if v["stato"] != "analisi" and (ids is None or v["id"] in ids)]
            for v in via:
                self.voci.remove(v)
        for v in via:
            if v.get("temp") and TEMP_ANALISI.resolve() in Path(v["sorgente"]).resolve().parents:
                shutil.rmtree(Path(v["sorgente"]).parent, ignore_errors=True)
        self.app.cambiato()
        return len(via)

    def avvia(self):
        with self.app.lock:
            if self.in_corso:
                return "Sta già analizzando."
            if not self.app.ffmpeg:
                return "FFmpeg non trovato: lancia «Installa requisiti.bat» e riavvia il PC."
            if not (QUI / NOME_MOTORE).is_file():
                return f"Manca {NOME_MOTORE} nella cartella La Culla del Caos."
            if not any(v["stato"] == "in_coda" for v in self.voci):
                return "Nessun file da analizzare."
            self.in_corso = True
            self.fermare = False
            threading.Thread(target=self._esegui, daemon=True).start()
        self.app.cambiato()
        return None

    def ferma(self):
        with self.app.lock:
            if not self.in_corso:
                return
            self.fermare = True
            proc = self.proc
        if proc and proc.poll() is None:
            try:
                proc.kill()
            except OSError:
                pass

    # numpy serve al motore: lo installo una volta sola
    def _controlla_numpy(self):
        if self.numpy_ok:
            return True
        py = python_console()
        try:
            r = subprocess.run([py, "-c", "import numpy"], capture_output=True, timeout=120, creationflags=SENZA_CONSOLE)
        except (OSError, subprocess.SubprocessError):
            r = None
        if r is not None and r.returncode == 0:
            self.numpy_ok = True
            return True
        with self.app.lock:
            self.fase = "Installo numpy, serve solo la prima volta (circa un minuto)…"
        self.app.cambiato()
        try:
            r = subprocess.run([py, "-m", "pip", "install", "--quiet", "numpy"],
                               capture_output=True, timeout=900, creationflags=SENZA_CONSOLE)
            ok = r.returncode == 0
            if not ok:  # Python installato per tutti gli utenti: serve la cartella dell'utente
                r = subprocess.run([py, "-m", "pip", "install", "--user", "--quiet", "numpy"],
                                   capture_output=True, timeout=900, creationflags=SENZA_CONSOLE)
                ok = r.returncode == 0
            if ok:  # controllo che il motore lo veda davvero
                r = subprocess.run([py, "-c", "import numpy"], capture_output=True, timeout=120, creationflags=SENZA_CONSOLE)
                ok = r.returncode == 0
        except (OSError, subprocess.SubprocessError):
            ok = False
        with self.app.lock:
            self.fase = ""
        self.numpy_ok = ok
        return ok

    def _esegui(self):
        try:
            if not self._controlla_numpy():
                with self.app.lock:
                    for v in self.voci:
                        if v["stato"] == "in_coda":
                            v.update(stato="errore", msg="Non riesco a installare numpy. Apri il Prompt dei comandi e scrivi:  py -m pip install numpy")
                return
            while not self.fermare and not self.app.in_chiusura.is_set():
                with self.app.lock:
                    voce = next((v for v in self.voci if v["stato"] == "in_coda"), None)
                    attesa = self.caricamenti > 0
                    if voce:
                        voce.update(stato="analisi", msg="", dettaglio="")
                if voce is None:
                    if attesa:
                        time.sleep(0.1)
                        continue
                    break
                self.app.cambiato()
                self._analizza(voce)
        finally:
            with self.app.lock:
                for v in self.voci:
                    if v["stato"] == "analisi":
                        v["stato"] = "in_coda"
                self.in_corso = False
                self.proc = None
                fatti = sum(v["stato"] == "fatto" for v in self.voci)
                errori = sum(v["stato"] == "errore" for v in self.voci)
            self.app.invia(self.app.stato())
            self.app.invia({"tipo": "fine_analisi", "fatti": fatti, "errori": errori, "annullato": self.fermare})

    def _analizza(self, voce):
        comando = [python_console(), str(QUI / NOME_MOTORE), "--json", "--ffmpeg", self.app.ffmpeg, voce["sorgente"]]
        try:
            proc = subprocess.Popen(comando, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    creationflags=SENZA_CONSOLE, cwd=str(QUI),
                                    env={**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"})
        except OSError as e:
            return self._errore(voce, f"Non riesco ad avviare l'analisi: {e}")
        with self.app.lock:
            self.proc = proc
        if self.fermare:
            proc.kill()
        try:
            out, err = proc.communicate(timeout=600)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, err = proc.communicate()
            return self._errore(voce, "L'analisi ci ha messo troppo: file troppo lungo o PC occupato.")
        with self.app.lock:
            self.proc = None
        if self.fermare:
            return None
        risultato = None
        for riga in out.decode("utf-8", "replace").splitlines():
            riga = riga.strip()
            if riga.startswith("{"):
                try:
                    risultato = json.loads(riga)
                except ValueError:
                    pass
        if not risultato:
            testo = err.decode("utf-8", "replace").strip()
            if "No module named" in testo:
                self.numpy_ok = None
                return self._errore(voce, "Manca numpy. Apri il Prompt dei comandi e scrivi:  py -m pip install numpy  (poi riapri La Culla del Caos)", testo[-500:])
            print(f"Analisi di {voce['nome']} non riuscita (codice {proc.returncode}):\n{testo[-2000:]}", flush=True)
            ultima = next((r for r in reversed(testo.splitlines()) if r.strip()), "")
            return self._errore(voce, "L'analisi non è riuscita: " + (ultima[:160] or f"il motore si è chiuso con codice {proc.returncode}"), testo[-1500:])
        if risultato.get("errore"):
            return self._errore(voce, risultato["errore"])
        risultato.pop("file", None)
        with self.app.lock:
            voce.update(stato="fatto", risultato=risultato)
        if voce.get("registro") and risultato.get("bpm"):
            ok, errore = aggiorna_registro(self.app.cartella(), self.app.nome_registro, voce["registro"],
                                           risultato.get("bpm"), risultato.get("chiave"))
            with self.app.lock:
                voce["salvato"] = ok
                if not ok:
                    voce["msg"] = f"Analizzato, ma non salvato nel registro: {errore}"
        self.app.cambiato()
        return None

    def _errore(self, voce, messaggio, dettaglio=""):
        with self.app.lock:
            voce.update(stato="errore", msg=messaggio, dettaglio=dettaglio)
        self.app.cambiato()


# --- Stato del programma ---------------------------------------------------------------

class App:
    def __init__(self):
        self.lock = threading.RLock()
        self.impostazioni = leggi_json(FILE_IMPOSTAZIONI)
        self.token = secrets.token_urlsafe(18)
        self.porta = 0
        self.clienti = []
        self.lavoro = None
        self.numero_lavori = 0
        self.log = collections.deque(maxlen=400)
        self.da_inviare = False
        self.avviato = time.time()
        self.ultimo_collegamento = 0.0
        self.ultimo_scollegamento = time.time()
        self.chiusura_chiesta = 0.0
        self.in_chiusura = threading.Event()
        self.server = None
        self.ffmpeg = self.ffprobe = None
        self.rileva_ffmpeg()
        self.conv = Convertitore(self)
        self.analisi = Analizzatore(self)
        self.aggiorna_script()

    def rileva_ffmpeg(self):
        self.ffmpeg = trova_ffmpeg()
        self.ffprobe = trova_ffprobe(self.ffmpeg)

    def opzioni_conv(self):
        imp = self.impostazioni
        cartella = imp.get("conv_cartella")
        return {
            "formato": imp.get("conv_formato") if imp.get("conv_formato") in ("mp3", "wav") else "wav",
            "kbps": imp.get("conv_kbps") if imp.get("conv_kbps") in KBPS_MP3 else 320,
            "freq48": bool(imp.get("conv_freq48")),
            "bit24": bool(imp.get("conv_bit24")),
            "cartella": Path(cartella) if cartella else CARTELLA_CONVERTITI,
        }

    def aggiorna_script(self):
        self.script = trova_script(self.impostazioni)
        (self.freq_predefinita, self.bit_predefinito,
         self.cartella_predefinita, self.nome_registro) = predefiniti(self.script)

    def cartella(self):
        scelta = self.impostazioni.get("cartella")
        return Path(scelta) if scelta else self.cartella_predefinita

    def stato(self, con_log=False):
        with self.lock:
            dati = {
                "tipo": "stato",
                "script": {
                    "trovato": bool(self.script),
                    "percorso": str(self.script) if self.script else "",
                    "freq_predefinita": self.freq_predefinita,
                    "bit_predefinito": self.bit_predefinito,
                },
                "ffmpeg": bool(self.ffmpeg),
                "impostazioni": {
                    "cartella": str(self.cartella()),
                    "cartella_scelta": bool(self.impostazioni.get("cartella")),
                    "freq48": bool(self.impostazioni.get("freq48")) or self.freq_predefinita == 48000,
                    "bit24": bool(self.impostazioni.get("bit24")) or self.bit_predefinito == 24,
                },
                "conv_impostazioni": {**self.opzioni_conv(), "cartella": str(self.opzioni_conv()["cartella"])},
                "lavoro": self.lavoro.istantanea() if self.lavoro else None,
                "conversione": self.conv.istantanea(),
                "analisi": self.analisi.istantanea(),
            }
            if con_log:
                dati["log"] = list(self.log)
            return dati

    # Eventi verso la finestra --------------------------------------------------------

    def invia(self, evento):
        with self.lock:
            for q in list(self.clienti):
                q.put(evento)

    def cambiato(self):
        self.da_inviare = True

    def registra_log(self, riga):
        with self.lock:
            self.log.append(riga)
        self.invia({"tipo": "log", "riga": riga})

    def ciclo_invio(self):
        while not self.in_chiusura.is_set():
            time.sleep(0.12)
            if self.da_inviare:
                self.da_inviare = False
                self.invia(self.stato())

    def aggiungi_cliente(self, q):
        with self.lock:
            self.clienti.append(q)
            self.ultimo_collegamento = time.time()
            if not self.ffmpeg:
                self.rileva_ffmpeg()

    def togli_cliente(self, q):
        with self.lock:
            if q in self.clienti:
                self.clienti.remove(q)
            self.ultimo_scollegamento = time.time()

    def guardiano(self):
        """Chiude il programma quando la finestra è chiusa e non sta lavorando."""
        while not self.in_chiusura.is_set():
            time.sleep(1)
            with self.lock:
                occupato = (self.lavoro is not None and self.lavoro.stato == "in_corso") \
                    or self.conv.in_corso or self.conv.caricamenti > 0 \
                    or self.analisi.in_corso or self.analisi.caricamenti > 0
                ora = time.time()
                if occupato:
                    continue
                if self.chiusura_chiesta and self.ultimo_collegamento < self.chiusura_chiesta \
                        and ora - self.chiusura_chiesta > 4:
                    break
                if self.clienti:
                    continue
                attesa = 90 if not self.ultimo_collegamento else 25
                riferimento = self.ultimo_scollegamento if self.ultimo_collegamento else self.avviato
                if ora - riferimento > attesa:
                    break
        self.chiudi()

    def chiudi(self):
        if self.in_chiusura.is_set():
            return
        self.in_chiusura.set()
        self.invia(None)
        try:
            if leggi_json(FILE_ISTANZA).get("token") == self.token:
                FILE_ISTANZA.unlink()
        except OSError:
            pass
        if self.server:
            threading.Thread(target=self.server.shutdown, daemon=True).start()

    # Azioni ----------------------------------------------------------------------

    def salva_impostazioni(self):
        scrivi_json(FILE_IMPOSTAZIONI, self.impostazioni)

    def avvia_lavoro(self, link):
        with self.lock:
            if self.lavoro and self.lavoro.stato == "in_corso":
                return None, "Sta già scaricando: aspetta che finisca o premi Annulla."
            if not self.script:
                return None, "Non trovo scarica_wav.py."
            cartella = self.cartella()
            try:
                cartella.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                return None, f"Non riesco a creare la cartella {cartella}: {e}"
            self.numero_lavori += 1
            self.log.clear()
            imp = self.impostazioni
            self.lavoro = Lavoro(self, self.numero_lavori, link, cartella,
                                 bool(imp.get("freq48")) or self.freq_predefinita == 48000,
                                 bool(imp.get("bit24")) or self.bit_predefinito == 24)
            threading.Thread(target=self.lavoro.esegui, daemon=True).start()
        self.invia(self.stato(con_log=True))
        return self.lavoro, None

    def fine_lavoro(self, lavoro):
        self.invia(self.stato())
        self.invia({"tipo": "fine", "nuovi": lavoro.nuovi, "stato": lavoro.stato})


app = App()


# --- Dialoghi di Windows (in un processo a parte, con tkinter) -----------------------------

CODICE_DIALOGO = r"""
import sys, tkinter as tk
from tkinter import filedialog
radice = tk.Tk()
radice.withdraw()
try:
    radice.attributes('-topmost', True)
    radice.update()
    radice.lift()
    radice.focus_force()
except Exception:
    pass
scelta = filedialog.askdirectory(parent=radice, initialdir=sys.argv[1], title=sys.argv[2], mustexist=False)
sys.stdout.write(scelta or '')
"""


def scegli_cartella(iniziale, titolo):
    iniziale = Path(iniziale)
    while not iniziale.exists() and iniziale.parent != iniziale:
        iniziale = iniziale.parent
    try:
        risultato = subprocess.run(
            [python_console(), "-c", CODICE_DIALOGO, str(iniziale), titolo],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
            creationflags=SENZA_CONSOLE, timeout=900,
            env={**os.environ, "PYTHONIOENCODING": "utf-8"})
    except (OSError, subprocess.SubprocessError) as e:
        return None, f"Non riesco ad aprire la finestra per scegliere la cartella: {e}"
    scelta = risultato.stdout.strip()
    if risultato.returncode != 0 and not scelta:
        return None, "Non riesco ad aprire la finestra per scegliere la cartella."
    return (str(Path(scelta)) if scelta else None), None


# --- Server locale ----------------------------------------------------------------------

TIPI = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
        ".js": "text/javascript; charset=utf-8", ".png": "image/png", ".ico": "image/x-icon",
        ".svg": "image/svg+xml", ".ttf": "font/ttf", ".woff2": "font/woff2", ".txt": "text/plain; charset=utf-8"}


class Gestore(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "ScaricaWAV"

    def log_message(self, *argomenti):
        pass

    # Risposte -------------------------------------------------------------------------

    def _invia(self, codice, corpo, tipo, extra=None):
        self.send_response(codice)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(corpo)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for chiave, valore in (extra or {}).items():
            self.send_header(chiave, valore)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(corpo)

    def _json(self, dati, codice=200):
        corpo = json.dumps(dati, ensure_ascii=False).encode("utf-8")
        self._invia(codice, corpo, "application/json; charset=utf-8", {"Cache-Control": "no-store"})

    def _file(self, percorso):
        try:
            corpo = percorso.read_bytes()
        except OSError:
            return self._json({"errore": "non trovato"}, 404)
        tipo = TIPI.get(percorso.suffix.lower(), "application/octet-stream")
        cache = "max-age=86400" if percorso.suffix.lower() in (".ttf", ".woff2", ".png", ".ico") else "no-cache"
        extra = {"Cache-Control": cache}
        if percorso.suffix.lower() == ".html":
            extra["Content-Security-Policy"] = (
                "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
                "font-src 'self'; connect-src 'self'; base-uri 'none'; frame-ancestors 'none'")
        self._invia(200, corpo, tipo, extra)

    # Controlli -----------------------------------------------------------------------

    def _host_valido(self):
        host = (self.headers.get("Host") or "").lower()
        return host in (f"127.0.0.1:{app.porta}", f"localhost:{app.porta}")

    def _token_valido(self, parametri):
        dato = self.headers.get("X-Token") or (parametri.get("t") or [""])[0]
        return bool(dato) and secrets.compare_digest(dato, app.token)

    def _corpo_json(self):
        lunghezza = int(self.headers.get("Content-Length") or 0)
        if lunghezza > 1_000_000:
            return None
        grezzo = self.rfile.read(lunghezza) if lunghezza else b""
        try:
            dati = json.loads(grezzo.decode("utf-8") or "{}")
            return dati if isinstance(dati, dict) else {}
        except ValueError:
            return {}

    # GET ---------------------------------------------------------------------------

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        url = urlparse(self.path)
        parametri = parse_qs(url.query)
        if not self._host_valido():
            return self._json({"errore": "host"}, 403)
        if url.path.startswith("/api/"):
            if not self._token_valido(parametri):
                return self._json({"errore": "token"}, 403)
            if url.path == "/api/ping":
                return self._json({"ok": True})
            if url.path == "/api/stato":
                return self._json(app.stato(con_log=True))
            if url.path == "/api/registro":
                voci, errore = leggi_registro(app.cartella(), app.nome_registro)
                return self._json({"voci": voci, "errore": errore,
                                   "percorso": str(app.cartella() / app.nome_registro)})
            if url.path == "/api/eventi":
                return self._eventi()
            if url.path == "/api/convertiti":
                cartella = app.opzioni_conv()["cartella"]
                return self._json({"voci": elenco_convertiti(cartella), "cartella": str(cartella)})
            return self._json({"errore": "sconosciuto"}, 404)
        nome = "index.html" if url.path in ("", "/") else unquote(url.path.lstrip("/"))
        percorso = (WEB / nome).resolve()
        radice = WEB.resolve()
        if radice != percorso and radice not in percorso.parents:
            return self._json({"errore": "non trovato"}, 404)
        return self._file(percorso)

    def _eventi(self):
        q = queue.Queue()
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        app.aggiungi_cliente(q)
        try:
            self._scrivi_evento(app.stato(con_log=True))
            while not app.in_chiusura.is_set():
                try:
                    evento = q.get(timeout=10)
                except queue.Empty:
                    self.wfile.write(b": ancora qui\n\n")
                    self.wfile.flush()
                    continue
                if evento is None:
                    break
                self._scrivi_evento(evento)
        except OSError:
            pass
        finally:
            app.togli_cliente(q)
            self.close_connection = True

    def _scrivi_evento(self, evento):
        dati = json.dumps(evento, ensure_ascii=False)
        self.wfile.write(f"data: {dati}\n\n".encode("utf-8"))
        self.wfile.flush()

    # POST ------------------------------------------------------------------------

    def do_POST(self):
        url = urlparse(self.path)
        parametri = parse_qs(url.query)
        if not self._host_valido() or not self._token_valido(parametri):
            self.close_connection = True
            return self._json({"errore": "accesso negato"}, 403)
        if url.path == "/api/converti/carica":
            return self._carica(parametri, app.conv, TEMP_CONV)
        if url.path == "/api/analisi/carica":
            return self._carica(parametri, app.analisi, TEMP_ANALISI)
        dati = self._corpo_json()
        if dati is None:
            self.close_connection = True
            return self._json({"errore": "richiesta troppo grande"}, 413)
        percorso = url.path

        if percorso == "/api/analisi/avvia":
            errore = app.analisi.avvia()
            return self._json({"errore": errore}, 409) if errore else self._json({"ok": True})

        if percorso == "/api/analisi/annulla":
            threading.Thread(target=app.analisi.ferma, daemon=True).start()
            return self._json({"ok": True})

        if percorso == "/api/analisi/togli":
            ids = None if dati.get("tutti") is True else [i for i in dati.get("ids") or [] if isinstance(i, int)]
            return self._json({"tolti": app.analisi.togli(ids)})

        if percorso == "/api/analisi/registro":
            # analizza i beat del registro senza BPM o tonalità (o solo quelli indicati) e scrive il risultato nel CSV
            voci, errore = leggi_registro(app.cartella(), app.nome_registro)
            if errore:
                return self._json({"errore": errore}, 500)
            scelti = dati.get("file") if isinstance(dati.get("file"), list) else None
            aggiunti, mancanti = 0, 0
            for b in voci:
                if scelti is not None and b["file"] not in scelti:
                    continue
                if scelti is None and b["bpm"] and b["tonalita"]:
                    continue
                percorso_file = Path(b["file"])
                if not percorso_file.is_absolute():
                    percorso_file = app.cartella() / percorso_file
                if not percorso_file.is_file():
                    mancanti += 1
                    continue
                voce, _ = app.analisi.aggiungi(percorso_file, b["titolo"] or percorso_file.name, False,
                                               registro_file=b["file"], dimensione=percorso_file.stat().st_size)
                if voce:
                    aggiunti += 1
            if not aggiunti:
                if mancanti:
                    return self._json({"errore": "I file di quei beat non ci sono più nella cartella."}, 404)
                return self._json({"errore": "Tutti i beat del registro hanno già BPM e tonalità."}, 409)
            errore = app.analisi.avvia()
            if errore and errore != "Sta già analizzando.":
                return self._json({"errore": errore}, 409)
            return self._json({"aggiunti": aggiunti, "mancanti": mancanti})

        if percorso == "/api/converti/avvia":
            errore = app.conv.avvia()
            return self._json({"errore": errore}, 409) if errore else self._json({"ok": True})

        if percorso == "/api/converti/annulla":
            threading.Thread(target=app.conv.ferma, daemon=True).start()
            return self._json({"ok": True})

        if percorso == "/api/converti/togli":
            ids = None if dati.get("tutti") is True else [i for i in dati.get("ids") or [] if isinstance(i, int)]
            return self._json({"tolti": app.conv.togli(ids)})

        if percorso == "/api/converti/di-nuovo":
            if not app.conv.di_nuovo():
                return self._json({"errore": "Non c'è niente da convertire di nuovo."}, 409)
            errore = app.conv.avvia()
            return self._json({"errore": errore}, 409) if errore else self._json({"ok": True})

        if percorso == "/api/ciao":
            app.chiusura_chiesta = time.time()
            return self._json({"ok": True})

        if percorso == "/api/scarica":
            link = []
            for voce in dati.get("link") or []:
                if isinstance(voce, str):
                    voce = voce.strip()
                    if re.fullmatch(r"https?://\S{3,2000}", voce) and voce not in link:
                        link.append(voce)
            if not link:
                return self._json({"errore": "Nessun link valido."}, 400)
            if len(link) > MAX_LINK:
                return self._json({"errore": f"Al massimo {MAX_LINK} link per volta."}, 400)
            _, errore = app.avvia_lavoro(link)
            if errore:
                return self._json({"errore": errore}, 409)
            return self._json({"ok": True})

        if percorso == "/api/annulla":
            lavoro = app.lavoro
            if lavoro and lavoro.stato == "in_corso":
                threading.Thread(target=lavoro.annulla, daemon=True).start()
            return self._json({"ok": True})

        if percorso == "/api/impostazioni":
            with app.lock:
                for chiave in ("freq48", "bit24", "conv_freq48", "conv_bit24"):
                    if isinstance(dati.get(chiave), bool):
                        app.impostazioni[chiave] = dati[chiave]
                if dati.get("conv_formato") in ("mp3", "wav"):
                    app.impostazioni["conv_formato"] = dati["conv_formato"]
                if dati.get("conv_kbps") in KBPS_MP3:
                    app.impostazioni["conv_kbps"] = dati["conv_kbps"]
                if dati.get("cartella_predefinita") is True:
                    app.impostazioni.pop("cartella", None)
                app.salva_impostazioni()
            app.cambiato()
            return self._json(app.stato())

        if percorso == "/api/scegli-cartella":
            per_conversione = dati.get("per") == "conv"
            if per_conversione:
                scelta, errore = scegli_cartella(app.opzioni_conv()["cartella"], "Dove salvo i file convertiti?")
            else:
                scelta, errore = scegli_cartella(app.cartella(), "Dove salvo i WAV?")
            if errore:
                return self._json({"errore": errore}, 500)
            if scelta:
                with app.lock:
                    app.impostazioni["conv_cartella" if per_conversione else "cartella"] = scelta
                    app.salva_impostazioni()
                app.cambiato()
            return self._json({"cartella": scelta})

        if percorso == "/api/trova-script":
            scelta, errore = scegli_cartella(QUI.parent, "Dov'è la cartella La Culla del Caos?")
            if errore:
                return self._json({"errore": errore}, 500)
            if not scelta:
                return self._json({"trovato": bool(app.script)})
            candidato = Path(scelta) / NOME_SCRIPT
            if not candidato.is_file():
                return self._json({"errore": f"In quella cartella non c'è {NOME_SCRIPT}."}, 400)
            with app.lock:
                app.impostazioni["script"] = str(candidato)
                app.salva_impostazioni()
                app.aggiorna_script()
            app.cambiato()
            return self._json({"trovato": True})

        if percorso == "/api/apri":
            return self._apri(dati)

        return self._json({"errore": "sconosciuto"}, 404)

    def _apri(self, dati):
        cosa = dati.get("cosa")
        valore = dati.get("valore") if isinstance(dati.get("valore"), str) else ""
        try:
            if cosa in ("cartella", "cartella-conv"):
                cartella = app.cartella() if cosa == "cartella" else app.opzioni_conv()["cartella"]
                cartella.mkdir(parents=True, exist_ok=True)
                apri_con_sistema(cartella)
            elif cosa == "registro":
                registro = app.cartella() / app.nome_registro
                if not registro.is_file():
                    return self._json({"errore": "Il registro non c'è ancora: arriva col primo beat scaricato."}, 404)
                apri_con_sistema(registro)
            elif cosa == "file":
                file = Path(valore)
                if not file.is_absolute():
                    file = app.cartella() / file
                if not file.is_file():
                    return self._json({"errore": "Il file non c'è più in quella cartella."}, 404)
                if SU_WINDOWS:
                    subprocess.Popen(f'explorer /select,"{file}"')
                else:
                    apri_con_sistema(file.parent)
            elif cosa == "url":
                if not re.match(r"https?://", valore):
                    return self._json({"errore": "Link non valido."}, 400)
                webbrowser.open(valore)
            else:
                return self._json({"errore": "Azione sconosciuta."}, 400)
        except OSError as e:
            return self._json({"errore": f"Non riesco ad aprirlo: {e}"}, 500)
        return self._json({"ok": True})

    def _carica(self, parametri, coda, temp):
        """Riceve un file trascinato nella finestra e lo mette in una coda (conversione o analisi)."""
        try:
            lunghezza = int(self.headers.get("Content-Length") or -1)
        except ValueError:
            lunghezza = -1
        if lunghezza < 0:
            self.close_connection = True
            return self._json({"errore": "Manca la dimensione del file."}, 411)
        if lunghezza > MAX_FILE_CONV:
            self.close_connection = True
            return self._json({"errore": "File troppo grande: il massimo è 4 GB."}, 413)
        nome = nome_sicuro((parametri.get("nome") or [""])[0], "audio")
        with app.lock:
            if len(coda.voci) >= MAX_CODA:
                self.close_connection = True
                return self._json({"errore": f"Al massimo {MAX_CODA} file nell'elenco: svuotalo e continua."}, 409)
            coda.caricamenti += 1
        app.cambiato()
        cartella = temp / f"in-{secrets.token_hex(6)}"
        try:
            try:
                cartella.mkdir(parents=True)
                destinazione = cartella / nome
                rimasti = lunghezza
                with open(destinazione, "wb") as f:
                    while rimasti > 0:
                        pezzo = self.rfile.read(min(1 << 20, rimasti))
                        if not pezzo:
                            raise ConnectionError("caricamento interrotto")
                        f.write(pezzo)
                        rimasti -= len(pezzo)
            except (OSError, ConnectionError) as e:
                shutil.rmtree(cartella, ignore_errors=True)
                self.close_connection = True
                return self._json({"errore": f"Non riesco a leggere {nome}: {e}"}, 500)
            voce, errore = coda.aggiungi(destinazione, nome, True, dimensione=lunghezza) if coda is app.analisi \
                else coda.aggiungi(destinazione, nome, True, lunghezza)
            if errore:
                shutil.rmtree(cartella, ignore_errors=True)
                return self._json({"errore": errore}, 409)
            return self._json({"id": voce["id"]})
        finally:
            with app.lock:
                coda.caricamenti -= 1
            app.cambiato()


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = not SU_WINDOWS  # su Windows permetterebbe di rubare una porta già occupata


# --- Finestra ----------------------------------------------------------------------------

def trova_edge():
    candidati = []
    for variabile in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        base = os.environ.get(variabile)
        if base:
            candidati.append(Path(base) / "Microsoft" / "Edge" / "Application" / "msedge.exe")
    for variabile in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        base = os.environ.get(variabile)
        if base:
            candidati.append(Path(base) / "Google" / "Chrome" / "Application" / "chrome.exe")
    for c in candidati:
        if c.is_file():
            return str(c)
    for nome in ("msedge", "microsoft-edge", "google-chrome", "chromium", "chromium-browser"):
        if percorso := shutil.which(nome):
            return percorso
    return None


def apri_finestra(url):
    browser = trova_edge()
    if browser:
        try:
            subprocess.Popen([browser, f"--app={url}", "--window-size=1160,820",
                              "--no-first-run", "--no-default-browser-check"],
                             creationflags=SENZA_CONSOLE,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except OSError:
            pass
    webbrowser.open(url)


def istanza_attiva():
    """Se l'interfaccia è già aperta, ritorna il suo indirizzo."""
    dati = leggi_json(FILE_ISTANZA)
    porta, token = dati.get("porta"), dati.get("token")
    if not porta or not token:
        return None
    apri = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    richiesta = urllib.request.Request(f"http://127.0.0.1:{porta}/api/ping",
                                       headers={"X-Token": token, "Host": f"127.0.0.1:{porta}"})
    try:
        with apri.open(richiesta, timeout=1.5) as risposta:
            if risposta.status == 200:
                return f"http://127.0.0.1:{porta}/?t={token}"
    except (OSError, ValueError):
        return None
    return None


def main():
    prepara_log()
    argomenti = sys.argv[1:]
    senza_finestra = "--nessuna-finestra" in argomenti
    porta = PORTA_PREDEFINITA
    if "--porta" in argomenti:
        try:
            porta = int(argomenti[argomenti.index("--porta") + 1])
        except (IndexError, ValueError):
            pass

    if not senza_finestra and (indirizzo := istanza_attiva()):
        apri_finestra(indirizzo)
        return 0

    try:
        server = Server(("127.0.0.1", porta), Gestore)
    except OSError:
        server = Server(("127.0.0.1", 0), Gestore)
    app.server = server
    app.porta = server.server_address[1]
    shutil.rmtree(TEMP_CONV, ignore_errors=True)  # resti di una volta precedente
    shutil.rmtree(TEMP_ANALISI, ignore_errors=True)
    indirizzo = f"http://127.0.0.1:{app.porta}/?t={app.token}"
    scrivi_json(FILE_ISTANZA, {"porta": app.porta, "token": app.token, "pid": os.getpid()})
    print(f"La Culla del Caos · interfaccia su {indirizzo}", flush=True)

    threading.Thread(target=app.ciclo_invio, daemon=True).start()
    threading.Thread(target=app.guardiano, daemon=True).start()
    if not senza_finestra:
        apri_finestra(indirizzo)
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        app.chiudi()
        lavoro = app.lavoro
        if lavoro and lavoro.stato == "in_corso":
            lavoro.annulla()
        app.conv.ferma()
        app.analisi.ferma()
        server.server_close()
        time.sleep(0.3)  # FFmpeg chiude i file prima che li cancelli
        shutil.rmtree(TEMP_CONV, ignore_errors=True)
        shutil.rmtree(TEMP_ANALISI, ignore_errors=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
