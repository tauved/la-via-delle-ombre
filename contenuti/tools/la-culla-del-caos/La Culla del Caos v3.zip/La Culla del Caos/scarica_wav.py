r"""
Scarica WAV - salva in WAV l'audio di link YouTube e YouTube Music, per i provini.

USO
  Doppio clic su "Scarica WAV.bat", incolla i link (uno per riga) e premi
  Invio su una riga vuota per partire. Puoi anche trascinare sul .bat un
  file .txt con un link per riga.

  Da terminale:
    py scarica_wav.py LINK [LINK ...]
    py scarica_wav.py lista.txt
    py scarica_wav.py --48k --24bit LINK
    py scarica_wav.py --cartella "D:\Beat" LINK
    py scarica_wav.py --aggiorna

COSA FA
  - Scarica il miglior audio disponibile e lo converte in WAV
    (di base 44,1 kHz / 16 bit: puoi cambiarlo nelle impostazioni qui sotto).
  - Salva in Musica\Beat per provini, con nome "Artista - Titolo.wav"
    (per i type beat al posto dell'artista c'è il canale del produttore).
  - Salta i link già scaricati, anche se rilanci la stessa playlist.
    Scarica una playlist intera solo se incolli il link della playlist:
    il link di un video aperto dentro una playlist o un mix scarica solo quel video.
  - Aggiorna registro_beat.csv (si apre con Excel): data, file, titolo, canale,
    link del video, link di acquisto/download trovati nella descrizione,
    BPM e tonalità se scritti nel titolo o nella descrizione.
  - Installa e tiene aggiornati da solo yt-dlp e Deno (controllo settimanale).

Requisiti: Python 3.10 o superiore e FFmpeg (li installa "Installa requisiti.bat").
"""

import argparse
import csv
import importlib
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import sysconfig
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

# --- Impostazioni: cambiale qui se vuoi -------------------------------------
CARTELLA = Path.home() / "Music" / "Beat per provini"
FREQUENZA = 44100          # Hz: 44100 o 48000, come il progetto nella DAW
BIT = 16                   # 16 o 24
GIORNI_TRA_AGGIORNAMENTI = 7
# -----------------------------------------------------------------------------

NOME_FILE = "%(artist,uploader|Sconosciuto)s - %(track,title)s.%(ext)s"
REGISTRO = "registro_beat.csv"
ARCHIVIO = ".scaricati.txt"
INTESTAZIONE = ["data", "file", "titolo", "artista_o_canale", "link",
                "link_acquisto_download", "bpm", "tonalità"]

CARTELLA_DATI = Path(os.environ.get("LOCALAPPDATA") or Path.home()) / "ScaricaWAV"
CONTROLLO = CARTELLA_DATI / "ultimo_aggiornamento"

URL_RE = re.compile(r"https?://[^\s<>\"'()\[\]{}]+", re.I)
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
NEGOZI = ("beatstars.com", "bsta.rs", "airbit.com", "traktrain.com", "soundee.com",
          "beatbrokerz.com", "gumroad.com", "payhip.com", "bandcamp.com", "soundclick.com")
SOCIAL = ("instagram.com", "tiktok.com", "twitter.com", "x.com", "facebook.com",
          "youtube.com", "youtu.be", "spotify.com", "snapchat.com", "discord.gg",
          "discord.com", "twitch.tv", "threads.net")
PAROLE_ACQUISTO = re.compile(
    r"buy|purchase|lease|licen[cs]|acquist|compra|download|free\s*dl|instant|price|prezz|store|shop",
    re.I)
BPM_RE = re.compile(r"(?<!\d)(\d{2,3})\s*bpm\b|\bbpm\s*[:=\-]?\s*(\d{2,3})(?!\d)", re.I)
TONALITA_RE = re.compile(
    r"(?:\bkey|\bscale|\btonalit[aà])\s*[:=\-]?\s*"
    r"([A-G](?:#|b|♯|♭)?(?:\s*(?:major|minor|maj|min|m)\b)?)(?![\w#♯♭])",
    re.I)


# --- Lettura di titolo e descrizione -----------------------------------------

def _dominio_tra(host, domini):
    return any(host == d or host.endswith("." + d) for d in domini)


def link_produttore(descrizione):
    """Link di acquisto o download nella descrizione (negozi di beat o righe tipo 'Buy: ...')."""
    trovati = []
    for riga in (descrizione or "").splitlines():
        for url in URL_RE.findall(riga):
            url = url.rstrip(".,;:!")
            host = urlparse(url).netloc.lower().removeprefix("www.")
            if _dominio_tra(host, SOCIAL):
                continue
            if (_dominio_tra(host, NEGOZI) or PAROLE_ACQUISTO.search(riga)) and url not in trovati:
                trovati.append(url)
    return " ".join(trovati[:3])


def trova_bpm(testo):
    for m in BPM_RE.finditer(testo or ""):
        valore = int(m.group(1) or m.group(2))
        if 50 <= valore <= 220:
            return str(valore)
    return ""


def trova_tonalita(testo):
    m = TONALITA_RE.search(testo or "")
    if not m:
        return ""
    tonalita = " ".join(m.group(1).split())
    return tonalita[0].upper() + tonalita[1:]


def link_da_testo(testo):
    return [u.rstrip(".,;:!") for u in URL_RE.findall(testo or "")]


# --- Preparazione -------------------------------------------------------------

def sistema_path_windows():
    """Rilegge il PATH dal registro di Windows: subito dopo un'installazione
    Esplora risorse può passare ai programmi un PATH vecchio."""
    if os.name != "nt":
        return
    import winreg
    voci = os.environ.get("PATH", "").split(os.pathsep)
    chiavi = [
        (winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"),
        (winreg.HKEY_CURRENT_USER, "Environment"),
    ]
    for radice, percorso in chiavi:
        try:
            with winreg.OpenKey(radice, percorso) as chiave:
                valore, _ = winreg.QueryValueEx(chiave, "Path")
        except OSError:
            continue
        voci += os.path.expandvars(str(valore)).split(os.pathsep)
    if os.environ.get("LOCALAPPDATA"):
        link_winget = Path(os.environ["LOCALAPPDATA"]) / "Microsoft" / "WinGet" / "Links"
        if link_winget.is_dir():
            voci.append(str(link_winget))
    visti, pulite = set(), []
    for voce in voci:
        voce = voce.strip()
        if voce and voce.lower() not in visti:
            visti.add(voce.lower())
            pulite.append(voce)
    os.environ["PATH"] = os.pathsep.join(pulite)


def controlla_ffmpeg():
    if shutil.which("ffmpeg") and shutil.which("ffprobe"):
        return True
    print("Non trovo FFmpeg, che serve per creare i WAV.")
    print('Lancia "Installa requisiti.bat" (oppure: winget install Gyan.FFmpeg) e riapri.')
    print("Se l'hai appena installato e non lo trova ancora, riavvia il PC.")
    return False


def _pip_install(pacchetto):
    comando = [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet",
               "--disable-pip-version-check", pacchetto]
    try:
        return subprocess.run(comando).returncode == 0
    except OSError:
        return False


def _rendi_importabile():
    """Alla prima installazione nella cartella utente Python non la vede ancora."""
    importlib.invalidate_caches()
    if importlib.util.find_spec("yt_dlp") is None:
        import site
        cartella_utente = site.getusersitepackages()
        if os.path.isdir(cartella_utente):
            site.addsitedir(cartella_utente)
            importlib.invalidate_caches()


def assicura_dipendenze(forza=False):
    ha_ytdlp = importlib.util.find_spec("yt_dlp") is not None
    deno_pip = importlib.util.find_spec("deno") is not None
    deno_sistema = shutil.which("deno") is not None
    try:
        scaduto = time.time() - CONTROLLO.stat().st_mtime > GIORNI_TRA_AGGIORNAMENTI * 86400
    except OSError:
        scaduto = True
    if ha_ytdlp and (deno_pip or deno_sistema) and not (scaduto or forza):
        return

    if ha_ytdlp:
        print("Controllo gli aggiornamenti di yt-dlp...")
    else:
        print("Installo yt-dlp (solo la prima volta, ci vuole circa un minuto)...")
    ok = _pip_install("yt-dlp[default]")
    if not ok and not ha_ytdlp:
        return
    if not ok:
        print("Aggiornamento non riuscito: uso la versione già installata.")

    # Deno serve a yt-dlp per superare i controlli JavaScript di YouTube.
    # Se è già installato nel sistema uso quello, altrimenti lo installo con pip.
    if deno_pip or not deno_sistema:
        if not deno_pip:
            print("Installo Deno (serve per YouTube)...")
        _pip_install("deno")

    if ok:
        try:
            CARTELLA_DATI.mkdir(parents=True, exist_ok=True)
            CONTROLLO.touch()
        except OSError:
            pass


def segna_da_aggiornare():
    try:
        CONTROLLO.unlink()
    except OSError:
        pass


def trova_deno():
    try:
        import deno  # pacchetto pip "deno"
        percorso = deno.find_deno_bin()
        if percorso and os.path.exists(percorso):
            return str(percorso)
    except Exception:
        pass
    if percorso := shutil.which("deno"):
        return percorso
    nome = "deno.exe" if os.name == "nt" else "deno"
    for schema in (None, f"{os.name}_user"):
        try:
            cartella = sysconfig.get_path("scripts", schema) if schema else sysconfig.get_path("scripts")
        except KeyError:
            continue
        if cartella and (Path(cartella) / nome).is_file():
            return str(Path(cartella) / nome)
    return None


# --- Download -----------------------------------------------------------------

def salva_registro(percorso, righe, interattivo):
    if not righe:
        return
    while True:
        try:
            nuovo = not percorso.exists() or percorso.stat().st_size == 0
            with percorso.open("a", newline="", encoding="utf-8-sig") as f:
                scrittore = csv.writer(f, delimiter=";")
                if nuovo:
                    scrittore.writerow(INTESTAZIONE)
                scrittore.writerows(righe)
            return
        except PermissionError:
            print(f"\n{percorso.name} è aperto (forse in Excel): chiudilo per aggiornarlo.")
            if not interattivo:
                return
            try:
                risposta = input("Premi Invio quando l'hai chiuso, oppure scrivi n per saltare: ")
            except EOFError:
                return
            if risposta.strip().lower() == "n":
                return


def scarica(link, cartella, frequenza, bit, deno, interattivo):
    import yt_dlp
    from yt_dlp.postprocessor.common import PostProcessor

    cartella.mkdir(parents=True, exist_ok=True)
    righe, salvati, saltati, errori = [], [], [], []
    avvisi = []                  # mostrati solo se poi il link non va a buon fine
    corrente = {"id": None}

    class Registra(PostProcessor):
        def run(self, info):
            file = Path(info.get("filepath") or "")
            testo = f"{info.get('title') or ''}\n{info.get('description') or ''}"
            righe.append([
                datetime.now().strftime("%d/%m/%Y"),
                file.name,
                info.get("title") or "",
                info.get("artist") or info.get("uploader") or info.get("channel") or "",
                info.get("webpage_url") or info.get("original_url") or "",
                link_produttore(info.get("description")),
                trova_bpm(testo),
                trova_tonalita(testo),
            ])
            salvati.append(file.name)
            avvisi.clear()
            print(f"   salvato: {file.name}")
            return [], info

    class Log:
        def debug(self, msg):
            msg = ANSI_RE.sub("", msg)
            if "has already been recorded in the archive" in msg:
                titolo = re.sub(r"^\[download\]\s*(?:[\w-]+:\s*)?", "", msg)
                titolo = titolo.replace("has already been recorded in the archive", "").strip()
                saltati.append(titolo)
                print(f"\n> {titolo}\n   già scaricato, lo salto")

        def warning(self, msg):
            avvisi.append(ANSI_RE.sub("", msg).removeprefix("WARNING: "))

        def error(self, msg):
            for avviso in avvisi:
                print(f"   avviso: {avviso}")
            avvisi.clear()
            msg = ANSI_RE.sub("", msg).removeprefix("ERROR: ")
            errori.append(msg)
            print(f"   errore: {msg}")

    def avanzamento(d):
        info = d.get("info_dict") or {}
        if info.get("id") != corrente["id"]:
            corrente["id"] = info.get("id")
            print(f"\n> {info.get('title') or info.get('id') or 'senza titolo'}")
        if d.get("status") == "downloading":
            totale = d.get("total_bytes") or d.get("total_bytes_estimate")
            fatto = d.get("downloaded_bytes") or 0
            if totale:
                print(f"\r   scarico... {min(100, int(fatto * 100 / totale)):3d}%", end="", flush=True)
        elif d.get("status") == "finished":
            print("\r   scarico... 100%")

    def post(d):
        if d.get("status") == "started" and d.get("postprocessor") == "ExtractAudio":
            print("   converto in WAV...")

    opzioni = {
        "format": "bestaudio/best",
        # La cartella va in "paths" e non nel modello del nome: così il limite
        # di lunghezza vale solo per il nome del file, non per tutto il percorso.
        "paths": {"home": str(cartella)},
        "outtmpl": NOME_FILE,
        "trim_file_name": 120,
        "windowsfilenames": True,
        "noplaylist": True,
        "download_archive": str(cartella / ARCHIVIO),
        "final_ext": "wav",
        "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "wav"}],
        "postprocessor_args": {
            "extractaudio+ffmpeg_o": ["-ar", str(frequenza),
                                      "-c:a", "pcm_s24le" if bit == 24 else "pcm_s16le"],
        },
        "ignoreerrors": True,
        "quiet": True,
        "noprogress": True,
        "logger": Log(),
        "progress_hooks": [avanzamento],
    }
    if deno:
        opzioni["js_runtimes"] = {"deno": {"path": deno}}

    with yt_dlp.YoutubeDL(opzioni) as ydl:
        # Aggiunto dopo la creazione: passato nelle opzioni verrebbe chiamato due volte.
        ydl.add_postprocessor_hook(post)
        ydl.add_post_processor(Registra(), when="after_move")
        for url in link:
            try:
                ydl.download([url])
            except Exception as e:  # con ignoreerrors non dovrebbe succedere
                errori.append(str(e))
                print(f"   errore: {e}")

    salva_registro(cartella / REGISTRO, righe, interattivo)
    return salvati, saltati, errori


# --- Interfaccia --------------------------------------------------------------

def link_da_argomenti(argomenti):
    link = []
    for arg in argomenti:
        if re.match(r"https?://", arg, re.I):
            link += link_da_testo(arg)
            continue
        try:
            percorso = Path(arg)
            if percorso.is_file():
                link += link_da_testo(percorso.read_text(encoding="utf-8", errors="ignore"))
                continue
        except OSError:
            pass
        print(f"Ignoro {arg}: non è un link né un file di testo.")
    return list(dict.fromkeys(link))


def chiedi_link():
    print()
    print("Incolla i link (YouTube o YouTube Music), uno per riga.")
    print("Riga vuota per partire, riga vuota subito per uscire.")
    link = []
    while True:
        try:
            riga = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not riga:
            break
        trovati = link_da_testo(riga)
        if not trovati:
            print("  (in questa riga non vedo un link, la salto)")
        link += trovati
    return list(dict.fromkeys(link))


def riepilogo(salvati, saltati, errori):
    parti = [f"{len(salvati)} salvati"]
    if saltati:
        parti.append(f"{len(saltati)} già presenti")
    if errori:
        parti.append(f"{len(errori)} non riusciti")
    print("\nFatto: " + ", ".join(parti) + ".")
    if errori:
        print("Alla prossima apertura controllo se c'è una versione nuova di yt-dlp:")
        print("chiudi, riapri e riprova (quelli già scaricati vengono saltati).")


def main():
    for flusso in (sys.stdout, sys.stderr):
        try:
            flusso.reconfigure(errors="replace")
        except (AttributeError, ValueError):
            pass

    parser = argparse.ArgumentParser(
        description="Scarica in WAV l'audio di link YouTube e YouTube Music.")
    parser.add_argument("link", nargs="*", help="link, oppure file .txt con un link per riga")
    parser.add_argument("--cartella",
                        help="cartella di destinazione (di base: %s)" % str(CARTELLA).replace("%", "%%"))
    parser.add_argument("--48k", dest="khz48", action="store_true", help="WAV a 48 kHz")
    parser.add_argument("--24bit", dest="bit24", action="store_true", help="WAV a 24 bit")
    parser.add_argument("--aggiorna", action="store_true", help="aggiorna subito yt-dlp e Deno")
    args = parser.parse_args()

    sistema_path_windows()
    if not controlla_ffmpeg():
        return 1
    assicura_dipendenze(forza=args.aggiorna)
    _rendi_importabile()
    if importlib.util.find_spec("yt_dlp") is None:
        print("Non sono riuscito a installare yt-dlp: controlla la connessione e riprova.")
        return 1
    deno = trova_deno()
    if not deno:
        print("Attenzione: non trovo Deno, e senza YouTube spesso non funziona.")
        print("Installalo con: winget install DenoLand.Deno")

    cartella = Path(args.cartella).expanduser() if args.cartella else CARTELLA
    frequenza = 48000 if args.khz48 else FREQUENZA
    bit = 24 if args.bit24 else BIT
    interattivo = not args.link
    link = [] if interattivo else link_da_argomenti(args.link)
    print(f"I WAV ({frequenza} Hz, {bit} bit) vanno in: {cartella}")

    codice, aperta = 0, False
    while True:
        if interattivo:
            link = chiedi_link()
        if not link:
            break
        salvati, saltati, errori = scarica(link, cartella, frequenza, bit, deno, interattivo)
        riepilogo(salvati, saltati, errori)
        if errori:
            codice = 1
            segna_da_aggiornare()
        if salvati and interattivo and not aperta and os.name == "nt":
            os.startfile(cartella)
            aperta = True
        if not interattivo:
            break
    return codice


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nInterrotto.")
        sys.exit(130)
