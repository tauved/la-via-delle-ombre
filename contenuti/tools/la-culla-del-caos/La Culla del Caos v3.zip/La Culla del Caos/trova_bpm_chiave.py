r"""
Trova BPM e chiave - stima tempo e tonalità di un file audio, come Tunebat.

Uso:
  py trova_bpm_chiave.py BRANO.wav [ALTRO.mp3 ...]
  py trova_bpm_chiave.py --json BRANO.wav       (risultato per programmi)

Serve numpy (py -m pip install numpy) e FFmpeg. È una stima: controlla a orecchio,
soprattutto metà/doppio tempo e la scelta tra una chiave minore e la sua relativa
maggiore, che usano le stesse note.
"""

from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys

import numpy as np

SR = 22050
MAX_SECONDI = 240.0
SENZA_CONSOLE = 0x08000000 if os.name == "nt" else 0

NOTE = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
NOTE_IT = ["Do", "Do#", "Re", "Re#", "Mi", "Fa", "Fa#", "Sol", "Sol#", "La", "La#", "Si"]
CAMELOT_MINORE = {8: "1A", 3: "2A", 10: "3A", 5: "4A", 0: "5A", 7: "6A", 2: "7A", 9: "8A",
                  4: "9A", 11: "10A", 6: "11A", 1: "12A"}
CAMELOT_MAGGIORE = {11: "1B", 6: "2B", 1: "3B", 8: "4B", 3: "5B", 10: "6B", 5: "7B", 0: "8B",
                    7: "9B", 2: "10B", 9: "11B", 4: "12B"}

OPZIONI = {
    "profilo": "temperley",
    "peso_basso": 0.3,
    "prior_centro": 120.0,
    "prior_sigma": 0.9,       # in ottave
    "comb_secondi": 6.0,
    "per_frame": True,
}


# --- Lettura dell'audio --------------------------------------------------------------

def trova_ffmpeg():
    if p := shutil.which("ffmpeg"):
        return p
    base = os.environ.get("LOCALAPPDATA")
    if os.name == "nt" and base:
        c = os.path.join(base, "Microsoft", "WinGet", "Links", "ffmpeg.exe")
        if os.path.isfile(c):
            return c
    return None


def leggi_audio(percorso, ffmpeg=None, inizio=0.0, durata=MAX_SECONDI):
    ffmpeg = ffmpeg or trova_ffmpeg()
    if not ffmpeg:
        raise RuntimeError("FFmpeg non trovato")
    comando = [ffmpeg, "-v", "error", "-nostdin", "-ss", f"{inizio:.3f}", "-t", f"{durata:.3f}",
               "-i", str(percorso), "-vn", "-ac", "1", "-ar", str(SR), "-f", "f32le", "pipe:1"]
    r = subprocess.run(comando, capture_output=True, creationflags=SENZA_CONSOLE)
    if r.returncode != 0:
        testo = r.stderr.decode("utf-8", "replace").strip()
        basso = testo.lower()
        if "invalid data" in basso or "invalid argument" in basso or "does not contain any stream" in basso \
                or "could not find codec" in basso or "moov atom" in basso:
            raise RuntimeError("Non è un file audio, o è danneggiato.")
        if "matches no streams" in basso:
            raise RuntimeError("Il file non contiene audio.")
        if "no such file" in basso:
            raise RuntimeError("Il file non c'è più.")
        righe = testo.splitlines()
        raise RuntimeError(righe[-1] if righe else "FFmpeg non riesce a leggere il file")
    return np.frombuffer(r.stdout, dtype=np.float32).astype(np.float32)


def durata_file(percorso, ffmpeg):
    ffprobe = None
    if ffmpeg:
        c = os.path.join(os.path.dirname(ffmpeg), "ffprobe" + (".exe" if os.name == "nt" else ""))
        ffprobe = c if os.path.isfile(c) else shutil.which("ffprobe")
    if not ffprobe:
        return None
    r = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of",
                        "default=nw=1:nk=1", str(percorso)], capture_output=True, creationflags=SENZA_CONSOLE)
    try:
        return float(r.stdout.decode().strip())
    except ValueError:
        return None


def finestre(x, n_fft, hop):
    if len(x) < n_fft:
        x = np.pad(x, (0, n_fft - len(x)))
    return np.lib.stride_tricks.sliding_window_view(x, n_fft)[::hop]


# --- Tempo ----------------------------------------------------------------------------

def inviluppo_attacchi(x, sr=SR, n_fft=1024, hop=256):
    """Flusso spettrale su bande logaritmiche: quanto 'attacca' il suono in ogni istante."""
    fps = sr / hop
    freq = np.fft.rfftfreq(n_fft, 1 / sr)
    bordi = np.geomspace(30.0, min(11000.0, sr / 2 - 1), 38)
    banco = np.zeros((len(bordi) - 2, len(freq)), dtype=np.float32)
    for i in range(len(bordi) - 2):
        a, c, b = bordi[i], bordi[i + 1], bordi[i + 2]
        sale = (freq - a) / (c - a)
        scende = (b - freq) / (b - c)
        banco[i] = np.clip(np.minimum(sale, scende), 0, None)
    banco /= banco.sum(axis=1, keepdims=True) + 1e-9
    finestra = np.hanning(n_fft).astype(np.float32)
    f = finestre(x, n_fft, hop)
    bande = np.empty((len(f), banco.shape[0]), dtype=np.float32)
    for i in range(0, len(f), 4096):
        spettro = np.abs(np.fft.rfft(f[i:i + 4096] * finestra, axis=1)).astype(np.float32)
        bande[i:i + 4096] = spettro @ banco.T
    logb = np.log1p(1000.0 * bande)
    flusso = np.maximum(0.0, np.diff(logb, axis=0)).sum(axis=1)
    flusso = np.concatenate([[0.0], flusso])
    # tolgo l'andamento lento e tengo solo gli attacchi
    w = int(fps * 0.5) | 1
    media = np.convolve(flusso, np.ones(w) / w, mode="same")
    o = np.maximum(0.0, flusso - media)
    return o, fps


def autocorrelazione(o, max_lag):
    o = o - o.mean()
    n = len(o)
    F = np.fft.rfft(o, 2 * n)
    r = np.fft.irfft(F * np.conj(F))[: max_lag + 1]
    r = r / np.maximum(1, n - np.arange(max_lag + 1))
    return r / (r[0] + 1e-12)


def punteggio_comb(r, fps, bpm, secondi):
    passo = 60.0 * fps / bpm
    k = max(1, int(secondi * fps / passo))
    lag = np.arange(1, k + 1) * passo
    lag = lag[lag < len(r) - 1]
    if not len(lag):
        return 0.0
    return float(np.interp(lag, np.arange(len(r)), r).mean())


def stima_tempo(x, opzioni=OPZIONI):
    o, fps = inviluppo_attacchi(x)
    if len(o) < fps * 4 or o.max() <= 0:
        return None
    max_lag = int(min(len(o) - 1, fps * 22))
    r = autocorrelazione(o, max_lag)
    griglia = np.arange(50.0, 220.01, 0.5)
    grezzo = np.array([punteggio_comb(r, fps, b, opzioni["comb_secondi"]) for b in griglia])
    prior = np.exp(-0.5 * (np.log2(griglia / opzioni["prior_centro"]) / opzioni["prior_sigma"]) ** 2)
    pesato = np.maximum(grezzo, 0) * prior
    i = int(np.argmax(pesato))
    # rifinitura su un tratto lungo: più battiti -> più precisione
    fine = np.arange(griglia[i] - 1.5, griglia[i] + 1.5001, 0.02)
    lungo = np.array([punteggio_comb(r, fps, b, min(20.0, (max_lag - 2) / fps)) for b in fine])
    bpm = float(fine[int(np.argmax(lungo))])
    # alternativa a metà o doppio tempo
    alt = bpm / 2 if bpm >= 110 else bpm * 2
    s_bpm = punteggio_comb(r, fps, bpm, opzioni["comb_secondi"])
    s_alt = punteggio_comb(r, fps, alt, opzioni["comb_secondi"])
    picco = np.sort(pesato)[::-1]
    sicurezza = float(np.clip((pesato[i] - np.median(pesato)) / (pesato[i] + 1e-9), 0, 1))
    return {"bpm": bpm, "alternativa": alt, "forza": s_bpm, "forza_alternativa": s_alt,
            "sicurezza": sicurezza}


# --- Chiave ------------------------------------------------------------------------------

PROFILI_CHIAVE = {
    # Shaath (ricavati da musica pop/elettronica) e un profilo di triade: insieme funzionano meglio
    "shaath": ([6.6, 2.0, 3.5, 2.3, 4.6, 4.0, 2.5, 5.2, 2.4, 3.7, 2.3, 3.4],
               [6.5, 2.7, 3.5, 5.4, 2.6, 3.5, 2.5, 5.2, 4.0, 2.7, 4.3, 3.2]),
    "triade": ([1, 0, .3, 0, 1, .4, 0, 1, 0, .3, 0, .3], [1, 0, .3, 1, 0, .4, 0, 1, .3, 0, .3, 0]),
}


def _spettro(x, n_fft, hop, fmin, fmax, sr=SR):
    freq = np.fft.rfftfreq(n_fft, 1 / sr)
    sel = (freq >= fmin) & (freq <= fmax)
    finestra = np.hanning(n_fft).astype(np.float32)
    f = finestre(x, n_fft, hop)
    S = np.empty((len(f), int(sel.sum())), dtype=np.float32)
    for i in range(0, len(f), 256):
        S[i:i + 256] = (np.abs(np.fft.rfft(f[i:i + 256] * finestra, axis=1)) ** 2)[:, sel]
    midi = 69 + 12 * np.log2(freq[sel] / 440.0)
    return S, midi


def _per_classe(S, midi, accordatura):
    classe = np.mod(np.round(midi - accordatura), 12).astype(int)
    C = np.zeros((len(S), 12), dtype=np.float64)
    for k in range(12):
        C[:, k] = S[:, classe == k].sum(axis=1)
    return C


def croma(x):
    """Croma per frame (energia per nota, tutte le ottave insieme), accordatura e note del basso."""
    S, midi = _spettro(x, 8192, 2048, 55.0, 1760.0)
    scarto = midi - np.round(midi)
    pesi = S.sum(axis=0)
    accordatura = np.angle(np.sum(pesi * np.exp(2j * np.pi * scarto))) / (2 * np.pi)
    C = np.sqrt(_per_classe(S, midi, accordatura))
    C /= C.sum(axis=1, keepdims=True) + 1e-9
    Sb, midib = _spettro(x, 16384, 4096, 40.0, 200.0)
    Cb = _per_classe(Sb, midib, accordatura)
    forte = Cb.max(axis=1) > 0.2 * Cb.max()
    basso = np.bincount(np.argmax(Cb, axis=1)[forte], minlength=12).astype(float)
    return C, basso, float(accordatura)


def _norm(v):
    v = v - v.mean()
    return v / (np.linalg.norm(v) + 1e-12)


def stima_chiave(x, opzioni=OPZIONI):
    C, basso, accordatura = croma(x)
    if C.sum() <= 0:
        return None
    v = _norm(np.median(C, axis=0))
    vb = _norm(basso) if basso.sum() > 0 else None
    punteggi = []
    for modo in ("maggiore", "minore"):
        for tonica in range(12):
            s = 0.0
            for nome, (mag, mino) in PROFILI_CHIAVE.items():
                p = _norm(np.roll(np.array(mag if modo == "maggiore" else mino, dtype=float), tonica))
                s += v @ p
                if vb is not None:
                    s += opzioni["peso_basso"] * (vb @ p)
            punteggi.append((s / len(PROFILI_CHIAVE), tonica, modo))
    punteggi.sort(reverse=True)
    migliore, secondo = punteggi[0], punteggi[1]
    margine = (migliore[0] - secondo[0]) / (abs(migliore[0]) + 1e-9)
    return {"tonica": migliore[1], "modo": migliore[2], "punteggio": migliore[0],
            "seconda": {"tonica": secondo[1], "modo": secondo[2]}, "margine": float(margine),
            "accordatura_cent": float(accordatura * 100)}


# --- Nomi ---------------------------------------------------------------------------------

def nome_chiave(tonica, modo):
    corta = NOTE[tonica] + ("m" if modo == "minore" else "")
    lunga = f"{NOTE_IT[tonica]} {modo}"
    camelot = (CAMELOT_MINORE if modo == "minore" else CAMELOT_MAGGIORE)[tonica]
    return corta, lunga, camelot


def relativa(tonica, modo):
    return ((tonica + 3) % 12, "maggiore") if modo == "minore" else ((tonica + 9) % 12, "minore")


def analizza(percorso, ffmpeg=None, opzioni=OPZIONI):
    ffmpeg = ffmpeg or trova_ffmpeg()
    durata = durata_file(percorso, ffmpeg)
    inizio = 0.0
    if durata and durata > MAX_SECONDI + 20:
        inizio = min(30.0, (durata - MAX_SECONDI) / 2)  # salto l'intro dei brani lunghi
    x = leggi_audio(percorso, ffmpeg, inizio)
    if len(x) < SR * 3:
        raise RuntimeError("Il file è troppo corto per capire BPM e chiave (servono almeno 3 secondi).")
    picco = float(np.max(np.abs(x)))
    if picco < 1e-4:
        raise RuntimeError("Il file è muto.")
    x = x / picco
    tempo = stima_tempo(x, opzioni)
    chiave = stima_chiave(x, opzioni)
    risultato = {"file": str(percorso), "durata": durata or len(x) / SR}
    if tempo:
        risultato.update(bpm=int(round(tempo["bpm"])), bpm_preciso=round(tempo["bpm"], 2),
                         bpm_alternativo=int(round(tempo["alternativa"])),
                         sicurezza_bpm=round(tempo["sicurezza"], 3))
    if chiave:
        corta, lunga, camelot = nome_chiave(chiave["tonica"], chiave["modo"])
        rt, rm = relativa(chiave["tonica"], chiave["modo"])
        r_corta, r_lunga, _ = nome_chiave(rt, rm)
        s_corta, s_lunga, _ = nome_chiave(chiave["seconda"]["tonica"], chiave["seconda"]["modo"])
        risultato.update(chiave=corta, chiave_nome=lunga, camelot=camelot, relativa=r_corta,
                         relativa_nome=r_lunga, seconda_ipotesi=s_corta, seconda_ipotesi_nome=s_lunga,
                         sicurezza_chiave=round(chiave["margine"], 3),
                         accordatura_cent=round(chiave["accordatura_cent"], 1))
    return risultato


def main(argomenti):
    in_json = "--json" in argomenti
    ffmpeg = None
    file = []
    i = 0
    while i < len(argomenti):
        a = argomenti[i]
        if a == "--json":
            pass
        elif a == "--ffmpeg" and i + 1 < len(argomenti):
            ffmpeg = argomenti[i + 1]
            i += 1
        else:
            file.append(a)
        i += 1
    if not file:
        print(__doc__)
        return 2
    codice = 0
    for percorso in file:
        try:
            r = analizza(percorso, ffmpeg)
        except Exception as e:  # noqa: BLE001 - qualsiasi errore va riportato
            r = {"file": percorso, "errore": str(e)}
            codice = 1
        if in_json:
            print(json.dumps(r, ensure_ascii=False), flush=True)
        elif "errore" in r:
            print(f"{os.path.basename(percorso)}: {r['errore']}")
        else:
            print(f"{os.path.basename(percorso)}: {r.get('bpm', '?')} BPM (o {r.get('bpm_alternativo', '?')}), "
                  f"{r.get('chiave_nome', '?')} ({r.get('chiave', '?')}, {r.get('camelot', '?')})")
    return codice


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
