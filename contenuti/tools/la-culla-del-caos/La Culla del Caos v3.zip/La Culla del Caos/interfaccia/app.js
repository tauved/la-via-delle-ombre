/* La Culla del Caos · interfaccia TAUH
   La pagina parla solo col programma locale (La Culla del Caos.pyw), che lancia
   scarica_wav.py per i download e FFmpeg per le conversioni. */
(() => {
  'use strict';

  const $ = (selettore, radice = document) => radice.querySelector(selettore);
  const token = new URLSearchParams(location.search).get('t') || '';
  const RE_URL = /https?:\/\/[^\s<>"'()[\]{}|]+/gi;
  const TITOLO = 'La Culla del Caos · TAUH';
  const FINITI = ['salvato', 'saltato', 'errore', 'annullato'];
  const NOMI_STATO = {
    scarico: 'Scarico', converto: 'Converto in WAV', salvato: 'Salvato',
    saltato: 'Già presente', errore: 'Errore', annullato: 'Annullato',
  };
  const NOMI_STATO_FILE = { analisi: 'Analizzo', in_coda: 'In coda', fatto: 'Fatto', errore: 'Errore' };
  const ESTENSIONI_TESTO = /\.(txt|csv|url|m3u8?)$/i;
  const ESTENSIONI_AUDIO = new Set(('mp3 wav wave opus ogg oga waptt m4a m4b aac amr awb 3gp 3ga 3g2 wma flac ' +
    'aif aiff aifc caf webm weba mka mkv mp4 m4v mov avi ac3 eac3 dts mp2 mpga wv ape alac au snd spx mpeg mpg ts flv')
    .split(' '));
  const SCHEDE = {
    scarica: {
      sottotitolo: 'Beat per i provini, da YouTube e YouTube Music',
      piede: 'Per i provini. Prima di pubblicare un pezzo, prendi la licenza del beat.',
      cartella: 'cartella',
    },
    converti: {
      sottotitolo: 'Qualsiasi audio, anche da WhatsApp, in MP3 o WAV',
      piede: 'Converte con FFmpeg, sul tuo PC: niente viene caricato su internet.',
      cartella: 'cartella-conv',
    },
    analisi: {
      sottotitolo: 'Tempo e tonalità di un beat, come su Tunebat',
      piede: 'Analisi sul tuo PC con FFmpeg e numpy: niente viene caricato su internet.',
      cartella: 'cartella',
    },
  };
  const NOTE_IT = { C: 'Do', 'C#': 'Do#', D: 'Re', 'D#': 'Re#', E: 'Mi', F: 'Fa', 'F#': 'Fa#', G: 'Sol', 'G#': 'Sol#', A: 'La', 'A#': 'La#', B: 'Si' };

  const el = {
    link: $('#link'), zona: $('#zona-link'), conta: $('#conta-link'),
    incolla: $('#incolla'), svuota: $('#svuota'),
    percorso: $('#percorso'), cambia: $('#cambia-cartella'),
    scarica: $('#scarica'), scaricaTesto: $('#scarica .scarica-testo'), badge: $('#badge-link'),
    fase: $('#fase'), annulla: $('#annulla'),
    schedaAvanzamento: $('#scheda-avanzamento'), voci: $('#voci'), riepilogo: $('#riepilogo'), log: $('#log'),
    cerca: $('#cerca'), beat: $('#beat'), beatVuoto: $('#beat-vuoto'), beatVuotoTesto: $('#beat-vuoto-testo'),
    beatConta: $('#beat-conta'), avvisi: $('#avvisi'), toast: $('#toast'), modelloVoce: $('#t-voce'),
    sottotitolo: $('#sottotitolo'), piedeNota: $('#piede-nota'), apriTestata: $('#apri-testata'),
    tabs: [...document.querySelectorAll('.tab')],
    zonaFile: $('#zona-file'), inputFile: $('#input-file'), coda: $('#coda'), contaCoda: $('#conta-coda'),
    diNuovo: $('#di-nuovo'), svuotaCoda: $('#svuota-coda'), percorsoConv: $('#percorso-conv'),
    cambiaConv: $('#cambia-cartella-conv'), converti: $('#converti'), convertiTesto: $('#converti-testo'),
    badgeCoda: $('#badge-coda'), faseConv: $('#fase-conv'), annullaConv: $('#annulla-conv'),
    convertiti: $('#convertiti'), convVuoto: $('#conv-vuoto'), convConta: $('#conv-conta'),
    modelloFile: $('#t-file'), trascinaOvunque: $('#trascina-ovunque'), zonaTitolo: $('#zona-titolo'),
    trascinaTesto: $('#trascina-testo'), zonaAnalisi: $('#zona-analisi'), zonaAnalisiTitolo: $('#zona-analisi-titolo'),
    inputAnalisi: $('#input-analisi'), faseAnalisi: $('#fase-analisi'), annullaAnalisi: $('#annulla-analisi'),
    svuotaAnalisi: $('#svuota-analisi'), risultati: $('#risultati'), modelloRisultato: $('#t-risultato'),
    completaRegistro: $('#completa-registro'),
  };

  let stato = null;
  let registro = [];
  let nuovi = 0;
  let nuoviFino = 0;
  let inviando = false;
  let vociViste = 0;
  let lavoroMostrato = 0;
  let scheda = 'scarica';
  let convertiti = [];
  let evidenziaConvFino = 0;
  let inviandoConv = false;
  let fileVisti = 0;
  const daCaricare = [];
  let caricando = false;
  let caricamentoFatti = 0;
  let caricamentoTotale = 0;
  let evidenziaUltimi = [];
  let ultimiNoti = 0;
  let correnteMostrato = 0;

  // --- Icone ---------------------------------------------------------------

  const SVG = 'http://www.w3.org/2000/svg';
  const PERCORSI = {
    esterno: 'M14 4h6v6M20 4l-9 9M18 14v4.5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6H10',
    file: 'M6 3.5h8l4 4V20a.5.5 0 0 1-.5.5h-11A.5.5 0 0 1 6 20zM14 3.5V8h4',
    video: 'M4 6.5h11a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1zM16 10.5l5-3v9l-5-3',
    avviso: 'M12 4 2.8 19.5h18.4zM12 10v4.5M12 17.2v.1',
    onda: 'M3 12h3l2.5-6 3 12 3-9 2 3H21',
    cartella: 'M3 7.5A1.5 1.5 0 0 1 4.5 6h4.2l2 2.2h8.8A1.5 1.5 0 0 1 21 9.7v8.8a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5z',
  };
  function icona(nome) {
    const svg = document.createElementNS(SVG, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    const p = document.createElementNS(SVG, 'path');
    p.setAttribute('d', PERCORSI[nome]);
    svg.append(p);
    return svg;
  }

  function crea(tag, classe, testo) {
    const nodo = document.createElement(tag);
    if (classe) nodo.className = classe;
    if (testo !== undefined) nodo.textContent = testo;
    return nodo;
  }

  const plurale = (n, uno, tanti) => `${n} ${n === 1 ? uno : tanti}`;

  function durataLeggibile(secondi) {
    if (!secondi) return '';
    const s = Math.round(secondi);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const r = String(s % 60).padStart(2, '0');
    return h ? `${h}:${String(m).padStart(2, '0')}:${r}` : `${m}:${r}`;
  }

  function dimensioneLeggibile(byte) {
    if (!byte && byte !== 0) return '';
    if (byte < 1024 * 1024) return `${Math.max(1, Math.round(byte / 1024))} KB`;
    if (byte < 1024 ** 3) return `${(byte / 1024 / 1024).toFixed(1).replace('.', ',')} MB`;
    return `${(byte / 1024 ** 3).toFixed(2).replace('.', ',')} GB`;
  }

  // --- Comunicazione col programma ---------------------------------------------

  async function api(percorso, dati) {
    const opzioni = { method: dati === undefined ? 'GET' : 'POST', headers: { 'X-Token': token } };
    if (dati !== undefined) {
      opzioni.headers['Content-Type'] = 'application/json';
      opzioni.body = JSON.stringify(dati);
    }
    const risposta = await fetch(percorso, opzioni);
    let corpo = {};
    try { corpo = await risposta.json(); } catch (_) { /* risposta vuota */ }
    if (!risposta.ok) throw new Error(corpo.errore || `Errore ${risposta.status}`);
    return corpo;
  }

  function collega() {
    const eventi = new EventSource('/api/eventi?t=' + encodeURIComponent(token));
    let fallimenti = 0;
    eventi.onopen = () => { fallimenti = 0; togliAvviso('connessione'); };
    eventi.onmessage = (e) => {
      let evento;
      try { evento = JSON.parse(e.data); } catch (_) { return; }
      if (evento.tipo === 'stato') applicaStato(evento);
      else if (evento.tipo === 'log') aggiungiLog(evento.riga);
      else if (evento.tipo === 'fine') fineLavoro(evento);
      else if (evento.tipo === 'fine_conv') fineConversione(evento);
      else if (evento.tipo === 'fine_analisi') fineAnalisi(evento);
    };
    eventi.onerror = () => {
      fallimenti += 1;
      if (fallimenti >= 2) {
        mostraAvviso('connessione', 'La Culla del Caos non risponde. Se hai chiuso il programma, riaprilo dal collegamento sul desktop.', true);
      }
    };
  }

  // --- Schede -------------------------------------------------------------------

  function mostraScheda(nome, salva = true) {
    if (!SCHEDE[nome]) nome = 'scarica';
    scheda = nome;
    for (const tab of el.tabs) {
      const attiva = tab.dataset.scheda === nome;
      tab.setAttribute('aria-selected', String(attiva));
      tab.tabIndex = attiva ? 0 : -1;
      $('#' + tab.getAttribute('aria-controls')).hidden = !attiva;
    }
    const info = SCHEDE[nome];
    el.sottotitolo.textContent = info.sottotitolo;
    el.piedeNota.textContent = info.piede;
    el.apriTestata.dataset.apri = info.cartella;
    if (nome === 'converti') caricaConvertiti();
    if (salva) {
      try { localStorage.setItem('scaricawav.scheda', nome); } catch (_) { /* niente */ }
    }
  }

  // --- Link -------------------------------------------------------------------

  function estraiLink(testo) {
    const visti = new Set();
    const link = [];
    for (const m of String(testo).matchAll(RE_URL)) {
      const url = m[0].replace(/[.,;:!?]+$/, '');
      if (!visti.has(url)) { visti.add(url); link.push(url); }
    }
    return link;
  }

  function linkCorrenti() { return estraiLink(el.link.value); }

  function aggiungiTesto(testo) {
    const trovati = estraiLink(testo);
    if (!trovati.length) { toast('Non ho trovato link da aggiungere.'); return; }
    const presenti = new Set(linkCorrenti());
    const daAggiungere = trovati.filter((u) => !presenti.has(u));
    if (daAggiungere.length) {
      const base = el.link.value.replace(/\s+$/, '');
      el.link.value = (base ? base + '\n' : '') + daAggiungere.join('\n') + '\n';
    }
    toast(daAggiungere.length ? `Aggiunti ${daAggiungere.length} link.` : 'Quei link ci sono già.');
    aggiornaPulsante();
  }

  // --- Stato -------------------------------------------------------------------

  function applicaStato(s) {
    stato = s;
    if (!s.script.trovato) {
      mostraAvviso('script', 'Non trovo scarica_wav.py: i download non partono. Copia questi file nella cartella La Culla del Caos, oppure indicami dov\'è.', true,
        { testo: 'Indica la cartella', azione: trovaScript });
    } else {
      togliAvviso('script');
    }
    if (!s.ffmpeg) mostraAvviso('ffmpeg', 'FFmpeg non risulta installato: lancia «Installa requisiti.bat» e riavvia il PC.', true);
    else togliAvviso('ffmpeg');

    impostaSegmenti('freq48', s.impostazioni.freq48, s.script.freq_predefinita === 48000,
      'Nello script la frequenza è 48 kHz: per avere 44,1 cambia FREQUENZA in cima a scarica_wav.py.');
    impostaSegmenti('bit24', s.impostazioni.bit24, s.script.bit_predefinito === 24,
      'Nello script la profondità è 24 bit: per avere 16 cambia BIT in cima a scarica_wav.py.');
    mostraPercorso(el.percorso, s.impostazioni.cartella);

    if (Array.isArray(s.log)) {
      el.log.textContent = s.log.join('\n');
      el.log.scrollTop = el.log.scrollHeight;
    }
    mostraLavoro(s.lavoro);
    aggiornaPulsante();
    if (s.conversione) {
      togliAvviso('versione');
      applicaConversione(s.conversione, s.conv_impostazioni);
      if (s.analisi) applicaAnalisi(s.analisi);
    } else {
      // pagina nuova servita dal programma vecchio, rimasto acceso durante l'aggiornamento
      mostraAvviso('versione', 'La Culla del Caos è stato aggiornato: chiudi questa finestra e riaprilo dal collegamento sul desktop.', true);
    }
  }

  function impostaSegmenti(chiave, attivo, bloccato, spiegazione) {
    const gruppo = document.querySelector(`.segmenti[data-opzione="${chiave}"]`);
    for (const b of gruppo.querySelectorAll('button')) {
      const valore = b.dataset.valore === 'true';
      b.setAttribute('aria-checked', String(valore === attivo));
      b.disabled = bloccato && !valore;
      b.title = b.disabled ? spiegazione : '';
    }
  }

  function mostraPercorso(nodo, percorso) {
    nodo.title = percorso;
    const parti = percorso.split(/[\\/]+/).filter(Boolean);
    const separatore = percorso.includes('\\') ? '\\' : '/';
    nodo.textContent = percorso.length > 46 && parti.length > 3
      ? '…' + separatore + parti.slice(-3).join(separatore)
      : percorso;
  }

  function mostraLavoro(lavoro) {
    const inCorso = !!lavoro && lavoro.stato === 'in_corso';
    document.body.classList.toggle('occupato', inCorso);
    el.tabs[0].querySelector('.tab-attivita').hidden = !inCorso;
    if (!lavoro) {
      el.schedaAvanzamento.hidden = true;
      el.fase.textContent = '';
      el.annulla.hidden = true;
      el.scarica.style.setProperty('--avanzamento', '0%');
      togliAvviso('lavoro');
      return;
    }
    el.schedaAvanzamento.hidden = false;
    sincronizzaVoci(lavoro.voci);
    if (inCorso && lavoro.numero !== lavoroMostrato && scheda === 'scarica') {
      // appena parte un download, la pagina scende fino al tasto e all'avanzamento
      lavoroMostrato = lavoro.numero;
      requestAnimationFrame(() => {
        const alto = el.scarica.getBoundingClientRect().top + window.scrollY - 24;
        if (alto > window.scrollY) window.scrollTo({ top: alto, behavior: 'smooth' });
      });
    }

    const totale = Math.max(lavoro.n_link, lavoro.voci.length, 1);
    const chiuse = lavoro.voci.filter((v) => FINITI.includes(v.stato)).length;
    let fase = lavoro.fase || '';
    if (inCorso && !fase) fase = `Brano ${Math.min(chiuse + 1, totale)} di ${totale}`;
    if (!inCorso) fase = lavoro.stato === 'annullato' ? 'Annullato.' : '';
    el.fase.textContent = fase;
    el.annulla.hidden = !inCorso;

    if (lavoro.avviso) mostraAvviso('lavoro', lavoro.avviso, false);
    else togliAvviso('lavoro');

    let fatto = 0;
    for (const v of lavoro.voci) {
      if (FINITI.includes(v.stato)) fatto += 1;
      else if (v.stato === 'converto') fatto += 0.95;
      else fatto += (v.pct || 0) / 100 * 0.9;
    }
    el.scarica.style.setProperty('--avanzamento', inCorso ? `${Math.min(100, (fatto / totale) * 100).toFixed(1)}%` : '0%');
    mostraRiepilogo(lavoro, inCorso);
  }

  function sincronizzaVoci(voci) {
    const esistenti = new Map([...el.voci.children].map((li) => [li.dataset.id, li]));
    voci.forEach((v, i) => {
      let li = esistenti.get(String(v.id));
      if (!li) {
        li = el.modelloVoce.content.firstElementChild.cloneNode(true);
        li.dataset.id = String(v.id);
      }
      esistenti.delete(String(v.id));
      li.className = 'voce ' + v.stato;
      const titolo = $('.voce-titolo', li);
      titolo.textContent = v.titolo || 'Senza titolo';
      titolo.title = v.titolo || '';
      const chip = $('.chip', li);
      chip.className = 'chip ' + v.stato;
      chip.textContent = v.stato === 'scarico' ? `Scarico ${v.pct || 0}%` : (NOMI_STATO[v.stato] || v.stato);
      $('.barra > span', li).style.width = (v.stato === 'scarico' ? (v.pct || 0) : 100) + '%';
      const messaggio = $('.voce-msg', li);
      messaggio.textContent = v.msg || '';
      messaggio.title = v.dettaglio || '';
      messaggio.hidden = !v.msg;
      if (el.voci.children[i] !== li) el.voci.insertBefore(li, el.voci.children[i] || null);
    });
    for (const li of esistenti.values()) li.remove();
    if (voci.length > vociViste) {
      el.voci.scrollTop = el.voci.scrollHeight;
    }
    vociViste = voci.length;
  }

  function mostraRiepilogo(lavoro, inCorso) {
    el.riepilogo.replaceChildren();
    if (inCorso || !lavoro.voci.length) return;
    const parti = [];
    const aggiungi = (n, uno, tanti) => {
      if (!n) return;
      const span = crea('span');
      span.append(crea('b', '', String(n)), ' ' + (n === 1 ? uno : tanti));
      parti.push(span);
    };
    aggiungi(lavoro.salvati, 'salvato', 'salvati');
    aggiungi(lavoro.saltati, 'già presente', 'già presenti');
    aggiungi(lavoro.errori, 'errore', 'errori');
    parti.forEach((p, i) => {
      if (i) el.riepilogo.append(crea('span', '', '·'));
      el.riepilogo.append(p);
    });
    if (lavoro.salvati) {
      const b = crea('button', 'btn piccolo');
      b.type = 'button';
      b.append(icona('cartella'), 'Apri cartella');
      b.addEventListener('click', () => apri('cartella'));
      el.riepilogo.append(b);
    }
  }

  function aggiornaPulsante() {
    const n = linkCorrenti().length;
    el.conta.replaceChildren();
    if (n) el.conta.append(crea('strong', '', String(n)), n === 1 ? ' link pronto' : ' link pronti');
    else el.conta.textContent = 'Nessun link';

    const inCorso = stato?.lavoro?.stato === 'in_corso';
    const pronto = n > 0 && !!stato?.script?.trovato && !inCorso && !inviando;
    el.scarica.disabled = !pronto;
    el.scarica.classList.toggle('in-corso', !!inCorso);
    el.scaricaTesto.textContent = inCorso ? 'Scarico' : 'Scarica';
    el.badge.textContent = String(n);
    el.badge.hidden = inCorso || n < 2;
    el.svuota.disabled = !el.link.value.trim();
  }

  function fineLavoro(evento) {
    nuovi = evento.nuovi || 0;
    nuoviFino = Date.now() + 20000;
    caricaRegistro();
    const lavoro = stato?.lavoro;
    if (evento.stato === 'finito' && lavoro) {
      if (!lavoro.errori && lavoro.voci.length) {
        el.link.value = '';
        aggiornaPulsante();
      }
      const testo = lavoro.errori
        ? `Download finito, con ${lavoro.errori === 1 ? 'un errore' : lavoro.errori + ' errori'}.`
        : (lavoro.salvati ? `Fatto: ${lavoro.salvati === 1 ? 'un beat salvato' : lavoro.salvati + ' beat salvati'}.` : 'Fatto: niente di nuovo da scaricare.');
      toast(testo, !!lavoro.errori);
      if (!document.hasFocus()) document.title = '✓ ' + TITOLO;
    }
  }

  // --- Registro ------------------------------------------------------------------

  async function caricaRegistro() {
    try {
      const risposta = await api('/api/registro');
      registro = risposta.voci || [];
      if (risposta.errore) toast(risposta.errore, true);
    } catch (_) { /* il programma è chiuso: resta quello che c'era */ }
    mostraRegistro();
  }

  function mostraRegistro() {
    const cerca = el.cerca.value.trim().toLowerCase();
    const evidenzia = !cerca && Date.now() < nuoviFino;
    const filtrate = cerca
      ? registro.filter((b) => [b.titolo, b.artista, b.bpm, b.tonalita, b.file, b.data].join(' ').toLowerCase().includes(cerca))
      : registro;
    el.beat.replaceChildren(...filtrate.slice(0, 300).map((b, i) => rigaBeat(b, evidenzia && i < nuovi)));
    el.beatVuoto.hidden = filtrate.length > 0;
    el.beatVuotoTesto.textContent = registro.length
      ? 'Nessun beat corrisponde alla ricerca.'
      : 'Il registro è vuoto: i beat che scarichi compaiono qui, con BPM, tonalità e link per la licenza.';
    el.beatConta.textContent = registro.length ? `· ${registro.length}` : '';
    const mancanti = registro.filter((b) => b.esiste && (!b.bpm || !b.tonalita)).length;
    el.completaRegistro.hidden = mancanti < 2;
    el.completaRegistro.title = `Analizza i ${mancanti} beat senza BPM o tonalità e li scrive nel registro`;
  }

  function rigaBeat(b, nuovo) {
    const li = crea('li', 'beat-riga' + (nuovo ? ' nuovo' : ''));
    const titolo = crea('div', 'beat-titolo', b.titolo || b.file || 'Senza titolo');
    titolo.title = b.titolo || '';
    const meta = crea('div', 'beat-meta', [b.artista, b.data].filter(Boolean).join(' · '));
    meta.title = b.file || '';
    const tag = crea('div', 'beat-tag');
    if (b.bpm) tag.append(crea('span', 'tag', /bpm/i.test(b.bpm) ? b.bpm : `${b.bpm} BPM`));
    if (b.tonalita) tag.append(crea('span', 'tag', b.tonalita));

    const azioni = crea('div', 'beat-azioni');
    for (const a of b.acquisto || []) {
      azioni.append(pulsanteAzione(`Licenza · ${a.nome}`, 'esterno', () => apri('url', a.url), 'licenza', a.url));
    }
    if (b.link) azioni.append(pulsanteAzione('Video', 'video', () => apri('url', b.link), '', b.link));
    if (b.esiste) azioni.append(pulsanteAzione('Mostra file', 'file', () => apri('file', b.file), '', b.file));
    if (b.esiste && (!b.bpm || !b.tonalita)) {
      azioni.append(pulsanteAzione('Trova BPM e chiave', 'onda', () => analizzaRegistro([b.file]), 'bpm',
        'Analizza il WAV e scrive BPM e tonalità nel registro'));
    }

    li.append(titolo, tag, meta);
    if (azioni.childElementCount) li.append(azioni);
    return li;
  }

  function pulsanteAzione(testo, nomeIcona, azione, classe, suggerimento) {
    const b = crea('button', 'azione' + (classe ? ' ' + classe : ''));
    b.type = 'button';
    b.title = suggerimento || '';
    b.append(icona(nomeIcona), testo);
    b.addEventListener('click', (e) => { e.stopPropagation(); azione(); });
    return b;
  }

  // --- Converti: stato ------------------------------------------------------------------

  function applicaConversione(c, imp) {
    impostaConv('conv_formato', imp.formato);
    impostaConv('conv_kbps', String(imp.kbps));
    impostaConv('conv_freq48', String(imp.freq48));
    impostaConv('conv_bit24', String(imp.bit24));
    for (const blocco of document.querySelectorAll('[data-solo]')) blocco.hidden = blocco.dataset.solo !== imp.formato;
    mostraPercorso(el.percorsoConv, imp.cartella);

    sincronizzaCoda(c.voci);
    const compatta = c.voci.length > 0;
    el.zonaFile.classList.toggle('compatta', compatta);
    el.zonaTitolo.textContent = compatta ? 'Trascina qui altri file, o' : 'Trascina qui i file audio';
    if ((c.ultimi || []).length !== ultimiNoti) {
      ultimiNoti = (c.ultimi || []).length;
      evidenziaUltimi = c.ultimi || [];
      if (ultimiNoti) {
        evidenziaConvFino = Date.now() + 20000;
        caricaConvertiti();
      }
    }
    const conta = { analisi: 0, in_coda: 0, converto: 0, fatto: 0, errore: 0 };
    for (const v of c.voci) conta[v.stato] = (conta[v.stato] || 0) + 1;
    const daFare = conta.analisi + conta.in_coda;
    const occupato = c.in_corso;
    el.tabs[1].querySelector('.tab-attivita').hidden = !(occupato || c.caricamenti > 0 || caricando);

    // conteggio sotto l'elenco
    el.contaCoda.replaceChildren();
    if (!c.voci.length) {
      el.contaCoda.textContent = 'Nessun file';
    } else {
      const parti = [];
      if (daFare + conta.converto) parti.push(`${daFare + conta.converto} da convertire`);
      if (conta.fatto) parti.push(plurale(conta.fatto, 'convertito', 'convertiti'));
      if (conta.errore) parti.push(plurale(conta.errore, 'con errore', 'con errore'));
      el.contaCoda.append(crea('strong', '', String(c.voci.length)), ` file${parti.length ? ' · ' + parti.join(' · ') : ''}`);
    }
    el.svuotaCoda.disabled = occupato || !c.voci.length;
    el.diNuovo.hidden = occupato || !conta.fatto;

    // tasto Converti
    const pronto = !occupato && daFare > 0 && !!stato?.ffmpeg && !inviandoConv && !caricando;
    el.converti.disabled = !pronto;
    el.converti.classList.toggle('in-corso', occupato);
    el.convertiTesto.textContent = occupato ? 'Converto' : 'Converti';
    el.badgeCoda.textContent = String(daFare);
    el.badgeCoda.hidden = occupato || daFare < 2;
    el.annullaConv.hidden = !occupato;

    let fase = '';
    if (occupato) {
      const g = c.giro;
      const totale = Math.max(1, g.fatti + g.errori + g.da_fare);
      const corrente = c.voci.find((v) => v.stato === 'converto');
      fase = `File ${Math.min(g.fatti + g.errori + 1, totale)} di ${totale}`;
      const avanzamento = (g.fatti + g.errori + (corrente ? (corrente.pct || 0) / 100 : 0)) / totale;
      el.converti.style.setProperty('--avanzamento', `${Math.min(100, avanzamento * 100).toFixed(1)}%`);
    } else {
      el.converti.style.setProperty('--avanzamento', '0%');
    }
    if (caricando) fase = `Preparo i file… ${caricamentoFatti} di ${caricamentoTotale}`;
    el.faseConv.textContent = fase;
  }

  function impostaConv(chiave, valore) {
    const gruppo = document.querySelector(`.segmenti[data-conv="${chiave}"]`);
    for (const b of gruppo.querySelectorAll('button')) b.setAttribute('aria-checked', String(b.dataset.valore === valore));
  }

  function sincronizzaCoda(voci) {
    const esistenti = new Map([...el.coda.children].map((li) => [li.dataset.id, li]));
    voci.forEach((v, i) => {
      let li = esistenti.get(String(v.id));
      if (!li) {
        li = el.modelloFile.content.firstElementChild.cloneNode(true);
        li.dataset.id = String(v.id);
        $('.togli', li).addEventListener('click', () => togliFile(v.id));
      }
      esistenti.delete(String(v.id));
      li.className = 'voce file ' + v.stato + (v.stato === 'converto' && !v.durata ? ' indeterminato' : '');
      const titolo = $('.voce-titolo', li);
      titolo.textContent = v.nome;
      titolo.title = v.nome;
      const chip = $('.chip', li);
      chip.className = 'chip ' + v.stato;
      chip.textContent = v.stato === 'converto'
        ? (v.durata ? `Converto ${v.pct || 0}%` : 'Converto')
        : (NOMI_STATO_FILE[v.stato] || v.stato);
      $('.togli', li).hidden = v.stato === 'converto';
      $('.barra > span', li).style.width = (v.pct || 0) + '%';

      const meta = $('.voce-meta', li);
      const firma = [v.whatsapp, v.codec, v.durata, v.video, v.dimensione].join('|');
      if (meta.dataset.firma !== firma) {
        meta.dataset.firma = firma;
        meta.replaceChildren();
        if (v.whatsapp) meta.append(crea('span', 'tag', 'WhatsApp'));
        const testo = [v.video ? 'Video' : '', v.codec, durataLeggibile(v.durata), dimensioneLeggibile(v.dimensione)]
          .filter(Boolean).join(' · ');
        meta.append(crea('span', '', testo || 'Analizzo il file…'));
      }

      const esito = $('.voce-esito', li);
      const firmaEsito = `${v.stato}|${v.uscita}|${v.msg}`;
      if (esito.dataset.firma !== firmaEsito) {
        esito.dataset.firma = firmaEsito;
        esito.replaceChildren();
        if (v.stato === 'fatto') {
          const testo = crea('span');
          testo.append('Salvato come ', crea('b', '', v.uscita_nome));
          esito.append(testo, pulsanteAzione('Mostra file', 'file', () => apri('file', v.uscita), '', v.uscita));
        } else if (v.stato === 'errore') {
          esito.textContent = v.msg;
          esito.title = v.dettaglio || '';
        }
      }
      esito.hidden = !esito.childNodes.length;
      if (el.coda.children[i] !== li) el.coda.insertBefore(li, el.coda.children[i] || null);
    });
    for (const li of esistenti.values()) li.remove();
    const corrente = voci.find((v) => v.stato === 'converto');
    if (corrente && corrente.id !== correnteMostrato) {
      correnteMostrato = corrente.id;
      const li = el.coda.querySelector(`[data-id="${corrente.id}"]`);
      if (li) el.coda.scrollTop = li.offsetTop - el.coda.offsetTop - el.coda.clientHeight / 2 + li.offsetHeight / 2;
    } else if (voci.length > fileVisti) {
      el.coda.scrollTop = el.coda.scrollHeight;
    }
    fileVisti = voci.length;
  }

  // --- Converti: file in arrivo -------------------------------------------------------

  function accodaFile(files, dest = 'converti') {
    files = files.filter(Boolean);
    if (!files.length) return;
    mostraScheda(dest);
    daCaricare.push(...files.map((file) => ({ file, dest })));
    caricamentoTotale += files.length;
    if (!caricando) caricaTutti();
    else aggiornaConvLocale();
  }

  async function caricaTutti() {
    caricando = true;
    const errori = [];
    aggiornaConvLocale();
    let perAnalisi = false;
    while (daCaricare.length) {
      const { file, dest } = daCaricare.shift();
      if (dest === 'analisi') perAnalisi = true;
      try {
        const risposta = await fetch(`/api/${dest}/carica?nome=` + encodeURIComponent(file.name), {
          method: 'POST', headers: { 'X-Token': token }, body: file,
        });
        if (!risposta.ok) {
          let corpo = {};
          try { corpo = await risposta.json(); } catch (_) { /* niente */ }
          throw new Error(corpo.errore || `errore ${risposta.status}`);
        }
      } catch (e) {
        errori.push(`${file.name}: ${e.message === 'Failed to fetch' ? 'non riesco a leggerlo' : e.message}`);
      }
      caricamentoFatti += 1;
      aggiornaConvLocale();
    }
    caricando = false;
    caricamentoFatti = 0;
    caricamentoTotale = 0;
    aggiornaConvLocale();
    if (perAnalisi) {
      try { await api('/api/analisi/avvia', {}); } catch (e) { if (!/già/.test(e.message)) toast(e.message, true); }
    } else {
      requestAnimationFrame(() => el.converti.scrollIntoView({ block: 'nearest', behavior: 'smooth' }));
    }
    if (errori.length) toast(errori.length === 1 ? errori[0] : `${errori.length} file non aggiunti. ${errori[0]}`, true);
  }

  function aggiornaConvLocale() {
    if (stato?.conversione) applicaConversione(stato.conversione, stato.conv_impostazioni);
    if (stato?.analisi) applicaAnalisi(stato.analisi);
  }

  function eAudio(nome) {
    const punto = nome.lastIndexOf('.');
    return punto > 0 && ESTENSIONI_AUDIO.has(nome.slice(punto + 1).toLowerCase());
  }

  function leggiFile(entry) {
    return new Promise((ok, ko) => entry.file(ok, ko));
  }

  async function fileDaEntries(entries, limite = 500) {
    const trovati = [];
    async function visita(entry, profondita) {
      if (trovati.length >= limite) return;
      if (entry.isFile) {
        // un file trascinato da solo si prova sempre; dentro una cartella solo l'audio
        if (profondita === 0 || eAudio(entry.name)) {
          try { trovati.push(await leggiFile(entry)); } catch (_) { /* illeggibile */ }
        }
      } else if (entry.isDirectory && profondita < 8) {
        const lettore = entry.createReader();
        const figli = [];
        for (;;) {
          const blocco = await new Promise((ok, ko) => lettore.readEntries(ok, ko)).catch(() => []);
          if (!blocco.length) break;
          figli.push(...blocco);
        }
        figli.sort((a, b) => a.name.localeCompare(b.name, 'it', { numeric: true }));
        for (const figlio of figli) await visita(figlio, profondita + 1);
      }
    }
    for (const entry of entries) await visita(entry, 0);
    return trovati;
  }

  function trascinaFile(dt) {
    return [...(dt?.types || [])].includes('Files');
  }

  function soloTesto(dt) {
    const elementi = [...(dt?.items || [])].filter((i) => i.kind === 'file');
    return elementi.length > 0 && elementi.every((i) => /^text\//.test(i.type));
  }

  function gestisciDrop(dt) {
    // questa parte deve restare sincrona: dopo l'evento il browser svuota i dati
    const entries = [];
    const files = [];
    for (const item of [...(dt.items || [])]) {
      if (item.kind !== 'file') continue;
      const entry = item.webkitGetAsEntry ? item.webkitGetAsEntry() : null;
      if (entry) entries.push(entry);
      else if (item.getAsFile()) files.push(item.getAsFile());
    }
    if (!dt.items?.length && dt.files?.length) files.push(...dt.files);
    const testo = `${dt.getData('text/uri-list') || ''}\n${dt.getData('text/plain') || ''}`;

    const eTesto = (nome) => ESTENSIONI_TESTO.test(nome);
    const entriesAudio = entries.filter((e) => !(e.isFile && eTesto(e.name)));
    const entriesTesto = entries.filter((e) => e.isFile && eTesto(e.name));
    const filesAudio = files.filter((f) => !eTesto(f.name));
    const filesTesto = files.filter((f) => eTesto(f.name));

    (async () => {
      if (entriesAudio.length || filesAudio.length) {
        const daCartelle = await fileDaEntries(entriesAudio);
        const tutti = [...filesAudio, ...daCartelle];
        if (!tutti.length) { toast('Nelle cartelle che hai trascinato non ci sono file audio.', true); return; }
        accodaFile(tutti, scheda === 'analisi' ? 'analisi' : 'converti');
        return;
      }
      let contenuto = testo;
      for (const e of entriesTesto) {
        try { contenuto += '\n' + await (await leggiFile(e)).text(); } catch (_) { /* illeggibile */ }
      }
      for (const f of filesTesto) contenuto += '\n' + await f.text();
      if (estraiLink(contenuto).length) {
        mostraScheda('scarica');
        aggiungiTesto(contenuto);
      } else if (entriesTesto.length || filesTesto.length) {
        toast('Non ho trovato link in quel file.', true);
      }
    })();
  }

  // trascinamento su tutta la finestra
  let trascinoInterno = false;
  let timerTrascina = 0;
  document.addEventListener('dragstart', () => { trascinoInterno = true; });
  document.addEventListener('dragend', () => { trascinoInterno = false; });

  function fineTrascina() {
    el.trascinaOvunque.hidden = true;
    document.body.classList.remove('trascino-file');
    el.zona.classList.remove('trascina');
  }

  window.addEventListener('dragover', (e) => {
    if (trascinoInterno) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    const file = trascinaFile(e.dataTransfer) && !soloTesto(e.dataTransfer);
    if (file) {
      document.body.classList.add('trascino-file');
      el.trascinaTesto.textContent = scheda === 'analisi' ? 'Rilascia per trovare BPM e chiave' : 'Rilascia per convertire';
      el.trascinaOvunque.hidden = (scheda === 'converti' && el.zonaFile.contains(e.target))
        || (scheda === 'analisi' && el.zonaAnalisi.contains(e.target));
    } else if (scheda === 'scarica') {
      el.zona.classList.add('trascina');
    }
    clearTimeout(timerTrascina);
    timerTrascina = setTimeout(fineTrascina, 250);
  });
  window.addEventListener('drop', (e) => {
    if (trascinoInterno) return;
    clearTimeout(timerTrascina);
    fineTrascina();
    const dt = e.dataTransfer;
    if (!trascinaFile(dt) && !estraiLink(`${dt.getData('text/uri-list')}\n${dt.getData('text/plain')}`).length) {
      return; // testo qualsiasi: lascio fare al browser
    }
    e.preventDefault();
    gestisciDrop(dt);
  });

  // file copiati in Esplora risorse e incollati con Ctrl+V
  window.addEventListener('paste', (e) => {
    const files = [...(e.clipboardData?.files || [])].filter((f) => !ESTENSIONI_TESTO.test(f.name));
    if (!files.length || document.activeElement === el.link) return;
    e.preventDefault();
    accodaFile(files, scheda === 'analisi' ? 'analisi' : 'converti');
  });

  // --- Converti: azioni -------------------------------------------------------------------

  async function converti() {
    if (el.converti.disabled) return;
    inviandoConv = true;
    aggiornaConvLocale();
    try { await api('/api/converti/avvia', {}); } catch (e) { toast(e.message, true); }
    inviandoConv = false;
    aggiornaConvLocale();
  }

  async function togliFile(id) {
    try { await api('/api/converti/togli', { ids: [id] }); } catch (e) { toast(e.message, true); }
  }

  function fineConversione(evento) {
    evidenziaConvFino = Date.now() + 20000;
    caricaConvertiti();
    if (evento.annullato) {
      toast('Conversione annullata: i file non convertiti restano in elenco.');
    } else if (evento.errori) {
      toast(`Finito: ${plurale(evento.fatti, 'file convertito', 'file convertiti')}, ${plurale(evento.errori, 'errore', 'errori')}.`, true);
    } else if (evento.fatti) {
      toast(`Fatto: ${plurale(evento.fatti, 'file convertito', 'file convertiti')}.`);
    }
    if (!document.hasFocus()) document.title = '✓ ' + TITOLO;
  }

  async function caricaConvertiti() {
    try {
      const risposta = await api('/api/convertiti');
      convertiti = risposta.voci || [];
    } catch (_) { /* il programma è chiuso */ }
    mostraConvertiti();
  }

  function mostraConvertiti() {
    const recenti = Date.now() < evidenziaConvFino ? new Set(evidenziaUltimi) : new Set();
    el.convertiti.replaceChildren(...convertiti.map((f) => {
      const li = crea('li', 'beat-riga conv' + (recenti.has(f.percorso) ? ' nuovo' : ''));
      const titolo = crea('div', 'beat-titolo', f.nome);
      titolo.title = f.percorso;
      const tag = crea('div', 'beat-tag');
      tag.append(crea('span', 'tag', f.formato));
      const meta = crea('div', 'beat-meta', [dimensioneLeggibile(f.dimensione), f.data].join(' · '));
      li.append(titolo, tag, meta, pulsanteAzione('Mostra file', 'file', () => apri('file', f.percorso), '', f.percorso));
      return li;
    }));
    el.convVuoto.hidden = convertiti.length > 0;
    el.convConta.textContent = convertiti.length ? `· ${convertiti.length}` : '';
  }

  // --- BPM e chiave ---------------------------------------------------------------------

  let risultatiVisti = 0;
  let ultimoFatto = 0;

  function nomeChiave(r) {
    const corta = r.chiave || '';
    const m = corta.match(/^([A-G]#?)(m?)$/);
    if (!m) return corta;
    return `${NOTE_IT[m[1]]} ${m[2] ? 'minore' : 'maggiore'}`;
  }

  function applicaAnalisi(a) {
    const occupato = a.in_corso || a.caricamenti > 0;
    el.tabs[2].querySelector('.tab-attivita').hidden = !occupato;
    if (!a.motore) mostraAvviso('motore', 'Manca trova_bpm_chiave.py nella cartella La Culla del Caos: copia tutti i file dello zip.', true);
    else togliAvviso('motore');
    sincronizzaRisultati(a.voci);
    const compatta = a.voci.length > 0;
    el.zonaAnalisi.classList.toggle('compatta', compatta);
    el.zonaAnalisiTitolo.textContent = compatta ? 'Trascina qui un altro beat, o' : 'Trascina qui un beat';
    const daFare = a.voci.filter((v) => v.stato === 'in_coda' || v.stato === 'analisi').length;
    const fatti = a.voci.filter((v) => v.stato === 'fatto').length;
    let fase = a.fase || '';
    if (!fase && a.in_corso) fase = `Analizzo… ${fatti + 1} di ${fatti + daFare}`;
    if (!fase && caricando && daCaricare.some((d) => d.dest === 'analisi')) fase = 'Preparo i file…';
    el.faseAnalisi.textContent = fase;
    el.annullaAnalisi.hidden = !a.in_corso;
    el.svuotaAnalisi.hidden = a.in_corso || !a.voci.length;
    if (fatti !== ultimoFatto) {
      ultimoFatto = fatti;
      if (a.voci.some((v) => v.stato === 'fatto' && v.registro)) caricaRegistro();
    }
  }

  function sincronizzaRisultati(voci) {
    const esistenti = new Map([...el.risultati.children].map((li) => [li.dataset.id, li]));
    // i più recenti in alto
    [...voci].reverse().forEach((v, i) => {
      let li = esistenti.get(String(v.id));
      if (!li) {
        li = el.modelloRisultato.content.firstElementChild.cloneNode(true);
        li.dataset.id = String(v.id);
        $('.togli', li).addEventListener('click', () => api('/api/analisi/togli', { ids: [v.id] }).catch((e) => toast(e.message, true)));
        $('.copia', li).addEventListener('click', async () => {
          const r = v.risultato || {};
          const testo = `${v.nome}: ${r.bpm} BPM (o ${r.bpm_alternativo}), ${nomeChiave(r)} (${r.chiave}, ${r.camelot})`;
          try { await navigator.clipboard.writeText(testo); toast('Copiato.'); } catch (_) { toast(testo); }
        });
      }
      esistenti.delete(String(v.id));
      li.className = 'risultato ' + v.stato + (v.stato === 'fatto' && v.id > risultatiVisti ? ' nuovo' : '');
      const nome = $('.ris-nome', li);
      nome.textContent = v.nome;
      nome.title = v.nome;
      const chip = $('.chip', li);
      if (v.stato === 'fatto' && v.registro) {
        chip.className = 'chip registro';
        chip.textContent = v.salvato ? 'Nel registro' : 'Fatto';
      } else {
        chip.className = 'chip ' + v.stato;
        chip.textContent = { in_coda: 'In coda', analisi: 'Analizzo', fatto: 'Fatto', errore: 'Errore' }[v.stato] || v.stato;
      }
      $('.togli', li).hidden = v.stato === 'analisi';
      const corpo = $('.ris-corpo', li);
      corpo.hidden = v.stato !== 'fatto';
      if (v.stato === 'fatto' && v.risultato && corpo.dataset.fatto !== '1') {
        corpo.dataset.fatto = '1';
        const r = v.risultato;
        $('.ris-bpm', li).textContent = r.bpm ?? '?';
        const alt = $('.bpm .ris-alt', li);
        const preciso = r.bpm_preciso && Math.abs(r.bpm_preciso - r.bpm) >= 0.05 ? ` · preciso ${String(r.bpm_preciso).replace('.', ',')}` : '';
        alt.replaceChildren('oppure ', crea('b', '', `${r.bpm_alternativo ?? '?'} BPM`), preciso);
        $('.ris-chiave', li).textContent = nomeChiave(r) || '?';
        const cam = $('.ris-camelot', li);
        cam.replaceChildren(crea('b', '', r.chiave || '?'), ' · Camelot ', crea('span', 'tag', r.camelot || '?'));
        $('.ris-relativa', li).replaceChildren('Relativa: ', crea('b', '', r.relativa_nome || '?'), ` (${r.relativa || '?'})`);
        $('.ris-seconda', li).replaceChildren('Seconda ipotesi: ', crea('b', '', r.seconda_ipotesi_nome || '?'), ` (${r.seconda_ipotesi || '?'})`);
        const acc = $('.ris-accordatura', li);
        const cent = Math.round(r.accordatura_cent || 0);
        acc.hidden = Math.abs(cent) < 15;
        acc.textContent = `Accordatura: ${cent > 0 ? '+' : ''}${cent} cent rispetto al La 440`;
        const fb = $('.bpm .fiducia', li);
        const fc = $('.chiave .fiducia', li);
        const sb = Math.min(1, (r.sicurezza_bpm || 0) * 1.3);
        const sc = Math.min(1, (r.sicurezza_chiave || 0) * 8);
        fb.firstElementChild.style.width = `${Math.round(sb * 100)}%`;
        fc.firstElementChild.style.width = `${Math.round(sc * 100)}%`;
        fb.classList.toggle('bassa', sb < 0.35);
        fc.classList.toggle('bassa', sc < 0.35);
        fb.title = sb < 0.35 ? 'Tempo poco netto: controlla a orecchio' : 'Tempo netto';
        fc.title = sc < 0.35 ? 'Tonalità incerta: prova anche la seconda ipotesi' : 'Tonalità netta';
      }
      const msg = $('.voce-msg', li);
      msg.replaceChildren(v.msg || '');
      if (v.dettaglio) {
        const det = crea('details', 'dettagli');
        det.append(crea('summary', '', 'Dettagli tecnici'), crea('pre', '', v.dettaglio));
        msg.append(det);
      }
      msg.hidden = !v.msg;
      if (el.risultati.children[i] !== li) el.risultati.insertBefore(li, el.risultati.children[i] || null);
    });
    for (const li of esistenti.values()) li.remove();
  }

  function fineAnalisi(evento) {
    risultatiVisti = Math.max(risultatiVisti, ...((stato?.analisi?.voci || []).filter((v) => v.stato !== 'fatto').map((v) => v.id)), 0);
    caricaRegistro();
    if (evento.annullato) toast('Analisi annullata.');
    else if (evento.errori) toast(`Analisi finita: ${plurale(evento.fatti, 'file', 'file')}, ${plurale(evento.errori, 'errore', 'errori')}.`, true);
    else if (evento.fatti) toast(`Fatto: ${plurale(evento.fatti, 'beat analizzato', 'beat analizzati')}.`);
    if (!document.hasFocus()) document.title = '✓ ' + TITOLO;
    setTimeout(() => { risultatiVisti = Math.max(...((stato?.analisi?.voci || []).map((v) => v.id)), 0); sincronizzaRisultati(stato?.analisi?.voci || []); }, 20000);
  }

  async function analizzaRegistro(file) {
    try {
      const r = await api('/api/analisi/registro', file ? { file } : {});
      mostraScheda('analisi');
      if (r.mancanti) toast(`${plurale(r.mancanti, 'beat saltato', 'beat saltati')}: il file non c'è più.`);
    } catch (e) {
      toast(e.message, true);
    }
  }

  el.zonaAnalisi.addEventListener('click', () => el.inputAnalisi.click());
  el.inputAnalisi.addEventListener('change', () => {
    accodaFile([...el.inputAnalisi.files], 'analisi');
    el.inputAnalisi.value = '';
  });
  el.annullaAnalisi.addEventListener('click', async () => {
    try { await api('/api/analisi/annulla', {}); } catch (e) { toast(e.message, true); }
  });
  el.svuotaAnalisi.addEventListener('click', async () => {
    try { await api('/api/analisi/togli', { tutti: true }); } catch (e) { toast(e.message, true); }
  });
  el.completaRegistro.addEventListener('click', () => analizzaRegistro(null));

  // --- Azioni generali ------------------------------------------------------------------

  async function scarica() {
    const link = linkCorrenti();
    if (!link.length || el.scarica.disabled) return;
    inviando = true;
    aggiornaPulsante();
    try {
      await api('/api/scarica', { link });
    } catch (e) {
      toast(e.message, true);
    } finally {
      inviando = false;
      aggiornaPulsante();
    }
  }

  async function apri(cosa, valore) {
    try { await api('/api/apri', { cosa, valore }); } catch (e) { toast(e.message, true); }
  }

  async function trovaScript() {
    try {
      const r = await api('/api/trova-script', {});
      if (r.trovato) toast('Trovato scarica_wav.py.');
    } catch (e) { toast(e.message, true); }
  }

  async function scegliCartella(bottone, per) {
    bottone.disabled = true;
    try {
      const r = await api('/api/scegli-cartella', per ? { per } : {});
      if (r.cartella) {
        toast('Cartella cambiata.');
        if (per === 'conv') caricaConvertiti(); else caricaRegistro();
      }
    } catch (e) {
      toast(e.message, true);
    } finally {
      bottone.disabled = false;
    }
  }

  // --- Avvisi e notifiche ----------------------------------------------------------

  const avvisi = new Map();

  function mostraAvviso(id, testo, grave, pulsante) {
    let box = avvisi.get(id);
    const firma = `${testo}|${grave}|${pulsante ? pulsante.testo : ''}`;
    if (box && box.dataset.firma === firma) return;
    if (!box) {
      box = crea('div', 'avviso');
      el.avvisi.append(box);
      avvisi.set(id, box);
    }
    box.dataset.firma = firma;
    box.classList.toggle('grave', !!grave);
    box.replaceChildren(icona('avviso'), crea('span', '', testo));
    if (pulsante) {
      const b = crea('button', 'btn piccolo', pulsante.testo);
      b.type = 'button';
      b.addEventListener('click', pulsante.azione);
      box.append(b);
    }
  }

  function togliAvviso(id) {
    const box = avvisi.get(id);
    if (box) { box.remove(); avvisi.delete(id); }
  }

  let timerToast = 0;
  function toast(testo, errore) {
    el.toast.textContent = testo;
    el.toast.classList.toggle('errore', !!errore);
    el.toast.classList.add('visibile');
    clearTimeout(timerToast);
    timerToast = setTimeout(() => el.toast.classList.remove('visibile'), 4500);
  }

  function aggiungiLog(riga) {
    const vicinoAlFondo = el.log.scrollHeight - el.log.scrollTop - el.log.clientHeight < 40;
    el.log.textContent += (el.log.textContent ? '\n' : '') + riga;
    if (el.log.textContent.length > 60000) el.log.textContent = el.log.textContent.slice(-40000);
    if (vicinoAlFondo) el.log.scrollTop = el.log.scrollHeight;
  }

  // --- Eventi della pagina -------------------------------------------------------------

  for (const tab of el.tabs) {
    tab.addEventListener('click', () => mostraScheda(tab.dataset.scheda));
    tab.addEventListener('keydown', (e) => {
      const i = el.tabs.indexOf(tab);
      let j = null;
      if (e.key === 'ArrowRight') j = (i + 1) % el.tabs.length;
      if (e.key === 'ArrowLeft') j = (i - 1 + el.tabs.length) % el.tabs.length;
      if (e.key === 'Home') j = 0;
      if (e.key === 'End') j = el.tabs.length - 1;
      if (j === null) return;
      e.preventDefault();
      mostraScheda(el.tabs[j].dataset.scheda);
      el.tabs[j].focus();
    });
  }

  el.link.addEventListener('input', aggiornaPulsante);
  el.link.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); scarica(); }
  });
  el.scarica.addEventListener('click', scarica);
  el.svuota.addEventListener('click', () => { el.link.value = ''; aggiornaPulsante(); el.link.focus(); });
  el.incolla.addEventListener('click', async () => {
    try {
      aggiungiTesto(await navigator.clipboard.readText());
    } catch (_) {
      el.link.focus();
      toast('Premi Ctrl+V nel riquadro per incollare.');
    }
  });
  el.annulla.addEventListener('click', async () => {
    el.annulla.disabled = true;
    try { await api('/api/annulla', {}); } catch (e) { toast(e.message, true); }
    el.annulla.disabled = false;
  });
  el.cambia.addEventListener('click', () => scegliCartella(el.cambia));
  el.cambiaConv.addEventListener('click', () => scegliCartella(el.cambiaConv, 'conv'));

  for (const gruppo of document.querySelectorAll('.segmenti[data-opzione]')) {
    gruppo.addEventListener('click', async (e) => {
      const b = e.target.closest('button');
      if (!b || b.disabled || b.getAttribute('aria-checked') === 'true') return;
      try {
        applicaStato(await api('/api/impostazioni', { [gruppo.dataset.opzione]: b.dataset.valore === 'true' }));
      } catch (err) {
        toast(err.message, true);
      }
    });
  }
  for (const gruppo of document.querySelectorAll('.segmenti[data-conv]')) {
    gruppo.addEventListener('click', async (e) => {
      const b = e.target.closest('button');
      if (!b || b.getAttribute('aria-checked') === 'true') return;
      const chiave = gruppo.dataset.conv;
      let valore = b.dataset.valore;
      if (chiave === 'conv_kbps') valore = Number(valore);
      else if (chiave !== 'conv_formato') valore = valore === 'true';
      try {
        applicaStato(await api('/api/impostazioni', { [chiave]: valore }));
      } catch (err) {
        toast(err.message, true);
      }
    });
  }

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-apri]');
    if (b) apri(b.dataset.apri);
  });
  el.cerca.addEventListener('input', mostraRegistro);

  el.zonaFile.addEventListener('click', () => el.inputFile.click());
  el.inputFile.addEventListener('change', () => {
    accodaFile([...el.inputFile.files]);
    el.inputFile.value = '';
  });
  el.converti.addEventListener('click', converti);
  el.annullaConv.addEventListener('click', async () => {
    el.annullaConv.disabled = true;
    try { await api('/api/converti/annulla', {}); } catch (e) { toast(e.message, true); }
    el.annullaConv.disabled = false;
  });
  el.svuotaCoda.addEventListener('click', async () => {
    try { await api('/api/converti/togli', { tutti: true }); } catch (e) { toast(e.message, true); }
  });
  el.diNuovo.addEventListener('click', async () => {
    try { await api('/api/converti/di-nuovo', {}); } catch (e) { toast(e.message, true); }
  });

  window.addEventListener('focus', () => {
    document.title = TITOLO;
    caricaRegistro();
    if (scheda === 'converti') caricaConvertiti();
  });
  window.addEventListener('pagehide', () => {
    try { navigator.sendBeacon('/api/ciao?t=' + encodeURIComponent(token)); } catch (_) { /* niente */ }
  });

  // --- Avvio -------------------------------------------------------------------------

  let schedaSalvata = 'scarica';
  try { schedaSalvata = localStorage.getItem('scaricawav.scheda') || 'scarica'; } catch (_) { /* niente */ }
  mostraScheda(schedaSalvata, false);

  if (!token) {
    mostraAvviso('token', 'Apri La Culla del Caos dal collegamento sul desktop: questa pagina da sola non può funzionare.', true);
  } else {
    collega();
    caricaRegistro();
  }
  aggiornaPulsante();
  if (scheda === 'scarica') el.link.focus();
})();
