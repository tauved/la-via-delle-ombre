@echo off
setlocal
title La Culla del Caos - collegamento sul desktop
cd /d "%~dp0"

if not exist "La Culla del Caos.pyw" (
    echo Non trovo "La Culla del Caos.pyw": tieni questo file nella stessa cartella.
    goto fine
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$qui = (Get-Location).Path;" ^
  "$desktop = [Environment]::GetFolderPath('Desktop');" ^
  "$shell = New-Object -ComObject WScript.Shell;" ^
  "$c = $shell.CreateShortcut((Join-Path $desktop 'La Culla del Caos.lnk'));" ^
  "$c.TargetPath = (Join-Path $qui 'La Culla del Caos.pyw');" ^
  "$c.WorkingDirectory = $qui;" ^
  "$c.IconLocation = (Join-Path $qui 'interfaccia\icona.ico') + ',0';" ^
  "$c.Description = 'La Culla del Caos - TAUH';" ^
  "$c.Save()"

if errorlevel 1 (
    echo Non sono riuscito a creare il collegamento.
) else (
    echo Fatto: sul desktop c'e' "La Culla del Caos" con il logo TAUH.
    echo Puoi anche aggiungerlo alla barra delle applicazioni: tasto destro, "Mostra altre opzioni", "Aggiungi alla barra delle applicazioni".
)

:fine
echo.
pause
